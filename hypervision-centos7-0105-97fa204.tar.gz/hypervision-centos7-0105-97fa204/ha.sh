#!/bin/bash

install_path=/home/satoshi/hypervision-suse11sp4-1228-3dd603
daemon_http_path=${install_path}/frontend
daemon_hpv_path=${install_path}/build
exec_http=httpserver
exec_hpv=hypervision
listen_port=9000
exec_user=satoshi
node_path=$install_path/node-v8.9.1-linux-x64

#start shell function 
startservice(){
    su $exec_user -c "cd $daemon_http_path >& /dev/null && daemon_http_opt=\"-listenAddr 0.0.0.0:$listen_port\" && ./$exec_http $daemon_http_opt >& /dev/null &"

    su $exec_user -c "export PATH=$PATH:$node_path/bin && cd $daemon_hpv_path >& /dev/null && ./$exec_hpv >& /dev/null &"

    declare -i retry=0
    while [ $retry -lt 30 ] ; do
        rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_http >& /dev/null)
        res1=$?
        rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_hpv >& /dev/null)
        res2=$?
        if ([ $res1 -eq 0 ] && [ $res2 -eq 0 ]); then
            return 0
        fi
        logger "SkybilityHA: Hypervision is starting......."
        sleep 1
        let retry=$retry+1
    done
    return 1 
}
#stop shell
function stopservice(){
    pkill $exec_http >& /dev/null
    pkill $exec_hpv >& /dev/null

    rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_http >& /dev/null)
    res1=$?
    rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_hpv >& /dev/null)
    res2=$?
    if ([ $res1 -ne 0 ] && [ $res2 -ne 0 ]); then
        return 0
    else
        return 1
    fi
}
#check sybase server status
servicestatus(){
    rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_http >& /dev/null)
    res1=$?
    rc=$(ps -ef --cols=1024 | grep -v grep | grep $exec_hpv >& /dev/null)
    res2=$?
    if ([ $res1 -eq 0 ] && [ $res2 -eq 0 ]); then
        state=up
    elif ([ $res1 -ne 0 ] && [ $res2 -ne 0 ]); then
        state=down
    fi

    if [ "$state" = "up" ]; then
        return 0
    elif [ "$state" = "down" ]; then
        return 1
    else
        return 2
    fi
}
# service main
MY_NAME=$(basename $0)
if [ $# -ne 1 ]; then
    echo "Usage: $MY_NAME {start|stop|status}"
    exit 1
fi

case $1 in
'start')
    servicestatus
    if [ $? -eq 0 ] ; then
        logger "SkybilityHA: Hypervision is already started"
        exit 0
    fi
    startservice
    echo -n "Start Hypervision :"
    servicestatus
    if [ $? -ne 0 ] ; then
        logger -i -p local0.error "[warning]SkybilityHA: Hypervision is not started; please check"
        exit 0
    fi
    logger "SkybilityHA: Hypervision is started"
    ;;
'stop')
    stopservice &
    declare -i retry1=0
    while [ $retry1 -eq 0 ] ; do
    servicestatus
    # only one process stopped, try again
    if [ $? -eq 1 ]; then
        logger "SkybilityHA: Hypervision stopped"
        exit 0
    fi
    logger "SkybilityHA: Hypervision is stopping......."
    sleep 1
    done
    ;;
'status')
    servicestatus
    res=$?
    if [ $res -eq 0 ]; then
        logger "SkybilityHA: Hypervision is running"
    elif [ $res -eq 1 ]; then
        logger "SkybilityHA: Hypervision stopped"
    else
        logger "[warning]SkybilityHA: Hypervision is not running properly; please check"
    fi
    exit 0
    ;;
esac
