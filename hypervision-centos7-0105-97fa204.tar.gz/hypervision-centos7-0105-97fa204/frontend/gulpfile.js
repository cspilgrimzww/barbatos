'use strict';
const gulp = require('gulp'),
htmlmin = require('gulp-htmlmin'), //html压缩
concat = require("gulp-concat"),
rename = require("gulp-rename"),
uglify = require('gulp-uglify'), // js压缩
notify = require('gulp-notify'); //提示信息

const BASE = __dirname + "/app/bower_components/";
const DIST_BASE = __dirname + "/dist/lib/"
gulp.task("default",function(){
   return gulp.src(['angular/angular.js',
        'angular-route/angular-route.js',
        'angular-loader/angular-loader.js',
    ].map((p)=>{return BASE+p;}))
        .pipe(concat("angular.js"))
        .pipe(gulp.dest(DIST_BASE+"angular/"));
});

//合并js并压缩
gulp.task('js', function () {
    gulp.src(['app/deviceView/*.js','app/service/*.js'])
        .pipe(concat('./app.js'))
        .pipe(gulp.dest('app/assets/js'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(uglify())
        .pipe(gulp.dest('app/assets/js'))
        .pipe(notify({
            message: 'js合并压缩完成'
        }));
});

//合并css并压缩
gulp.task('css', function () {
    gulp.src(['assets/css/*.css'])
        .pipe(concat('app/style.css'))
        .pipe(gulp.dest('./assets/css'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(minifycss())
        .pipe(gulp.dest('./assets/css'));
});