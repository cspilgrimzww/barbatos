package main

import (
    "net/http"
    "flag"
    "log"
)

func main() {
	listenAddr := flag.String("listenAddr", "0.0.0.0:9000", "listen-port not given")
	flag.Parse()
    http.Handle("/", http.FileServer(http.Dir("./")))
	log.Printf("Http server listening on :% v", *listenAddr)
	log.Fatal(http.ListenAndServe(*listenAddr, nil))
}