define([
    'angular',
], function () {
    var module = angular.module('filters');
    module.filter( 'hexStringToNum', function(){
        return function(str) {
            return parseInt(str, 16)
        }
    })

});