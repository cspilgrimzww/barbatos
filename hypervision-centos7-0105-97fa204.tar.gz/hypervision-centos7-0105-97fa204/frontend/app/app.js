define([
	'angular',
	'ngCookies',
	'ngAnimate',
	'ngRoute',
	'ngSanitize',
	'ngBindonce',
	'ngTranslate',
	'ngStaticLoader',
	'ngPaging',
    'ace',
	'angularPopups'
], function () {
	var initialize = function () {
		var i18n = angular.module('i18n', ['ngCookies']);
        var aceModule =angular.module('ui.ace',[]);
		var controllersModule = angular.module('controllers', ['pascalprecht.translate', 'angular-popups']);
		var directivesModule = angular.module('directives', []);
		var servicesModule = angular.module('services', []);
		var filtersModule = angular.module('filters', []);
		var routesModule = angular.module('routers', ['ngRoute']);
		var app = angular.module('app', ['ngAnimate', 'ngCookies', 'ngSanitize', 'pascalprecht.translate',
			'pasvaz.bindonce', 'controllers', 'directives', 'i18n', 'services',
			'filters', 'routers', 'bw.paging']);
		var v = "1.0.0";
		angular.module('app')
			.factory('timeoutHttpIntercept', function ($rootScope, $q) {
				return {
					'request': function (config) {
						config.timeout = 120000;
						return config;
					}
				};
			});
		//config translate to load static file
		app.config(function ($translateProvider, $httpProvider) {
			$httpProvider.defaults.cache = false;
			$httpProvider.interceptors.push('timeoutHttpIntercept');
			$translateProvider.useStaticFilesLoader({
				files: [{
					prefix: 'app/i18n/i18n_',
					suffix: '.json'
				}]
			});
			$translateProvider.registerAvailableLanguageKeys(['en', 'zh'], {
				'en_US': 'en',
				'zh_CN': 'zh'
			});
			//set preferred lang
			var locallang = localStorage.getItem('setlanguage');
			if (locallang) {
				var lang = locallang;
			} else {
				var lang = 'zh';
			}
			$translateProvider.preferredLanguage(lang);
			//auto determine preferred lang
			//$translateProvider.determinePreferredLanguage();
			//when can not determine lang, choose en lang.
			//$translateProvider.fallbackLanguage('en');
		});
		require([
			'appServices',
			'appControllers',
			'appDirectives',
			'appFilters',
			'router'
		], function () {
			angular.element(document).ready(function () {
				angular.bootstrap(document, ["app"]);
			});
		});
	};

	return {
		initialize: initialize
	};

});