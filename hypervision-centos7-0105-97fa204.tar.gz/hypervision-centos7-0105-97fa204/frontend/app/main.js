require.config({
	baseUrl: '',
	paths: {
		angular: 'vendor/angular/angular.min',
		ngAnimate: 'vendor/angular/angular-animate.min',
		ngCookies: 'vendor/angular/angular-cookies',
		ngRoute: 'vendor/angular/angular-route',
		ngSanitize: 'vendor/angular/angular-sanitize',
		ngBindonce: 'vendor/angular/bindonce.min',
		ngTranslate: 'vendor/angular/angular-translate.min',
		ngPaging: 'vendor/angular/angular-paging',
		ngStaticLoader: 'vendor/angular/angular-translate-loader-static-files',
		grid: 'vendor/angular/ui-grid',
		jquery: 'vendor/jquery/jquery',
		jqueryui: 'vendor/jquery/jquery-ui',
		highchart: 'vendor/highchart/js/highcharts',
		i18n_en: 'app/i18n/i18n_en',
		i18n_zh: 'app/i18n/i18n_zh',
		router: 'app/routers/router',
		appServices: 'app/services/all',
		appControllers: 'app/controllers/all',
		appDirectives: 'app/directives/all',
		appFilters: 'app/filters/all',
		toastr: 'vendor/toastr/toastr.min',
		SweetAlertAngular:'bower_components/angular-sweetalert/SweetAlert.min',
		SweetAlert:'bower_components/sweetalert/dist/sweetalert.min',
		ace:'vendor/ace-builds/src/ace',
		aceAngular:'vendor/ace-angular/ace-angular',
		uiAce:'vendor/angular-ui-ace/ui-ace',
		echarts:'vendor/echarts/echarts',
		angularPopups: 'bower_components/angular-popups/dist/angular-popups'
	},
	shim: {
		highchart: {
			deps: ['jquery']
		},
		jqueryui: {
			deps: ['jquery']
		},
		ngAnimate: {
			exports: 'ngAnimate',
			deps: ['angular']
		},
		ngCookies: {
			exports: 'ngCookies',
			deps: ['angular']
		},
		ngRoute: {
			exports: 'ngRoute',
			deps: ['angular']
		},
		ngSanitize: {
			exports: 'ngSanitize',
			deps: ['angular']
		},
		ngBindonce: {
			exports: 'ngBindonce',
			deps: ['angular']
		},
		ngTranslate: {
			exports: 'ngTranslate',
			deps: ['angular']
		},
		ngPaging: {
			exports: 'ngPaging',
			deps: ['angular']
		},
		ngStaticLoader: {
			exports: 'ngStaticLoader',
			deps: ['angular', 'ngTranslate']
		},
		toastr: {
			deps: ['jquery']
		},
		angularPopups: {
			exports: 'angularPopups',
			deps: ['angular']
		}
	}
});

require([
	'app/app'
], function (app) {
	app.initialize();
});
