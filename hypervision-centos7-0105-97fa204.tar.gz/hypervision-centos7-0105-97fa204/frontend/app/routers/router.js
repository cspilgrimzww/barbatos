define([
	'angular'
], function () {

	var module = angular.module('routers');

	module.config(function ($routeProvider) {
		$routeProvider
			.when('/', {
				templateUrl: 'app/templates/summary/summary.html',
				controller: 'summaryController'
			})
			.when('/summary', {
				templateUrl: 'app/templates/summary/summary.html',
				controller: 'summaryController'
			})
			.when('/server', {
				templateUrl: 'app/templates/server/server.html',
				controller: 'serverController',
				controllerAs: 'ServerCtrl'
			})
            .when('/server/detail', {
                templateUrl: 'app/templates/server/server_container.html',
                controller: 'serverDetailController',
                controllerAs: 'SDCtrl'
            })
			.when('/project', {//contract
				templateUrl: 'app/templates/contract/project_index.html',
				controller: 'projectController'
			})
			.when('/project/contractAdd', {//contractAdd
				templateUrl: 'app/templates/contract/contract_add.html',
				controller: 'contractAddController'
			})
			.when('/project/contract/:id', {//contract
				templateUrl: 'app/templates/contract/contract_index.html',
				controller: 'contractController'
			})
//			.when('/contract', {//contract
//				templateUrl: 'app/templates/contract/contract_index.html',
//				controller: 'contractController'
//			})
			.when('/contractAdd', {//contractAdd
				templateUrl: 'app/templates/contract/contract_add.html',
				controller: 'contractAddController'
			})
			.when('/project/contractDetail', {//contractDetail
				templateUrl: 'app/templates/contract/contract_detail.html',
				controller: 'contractDetailController'
			})
			.when('/project/contractGlance', {//contractDetail
				templateUrl: 'app/templates/contract/contract_glance.html',
				controller: 'contractGlanceController'
			})
			.when('/contractEdit', {//contractDetail
				templateUrl: 'app/templates/contract/contract_edit.html',
				controller: 'contractEditController'
			})
			.when('/contractInvoke', {//contractDetail
				templateUrl: 'app/templates/contract/contract_invoke.html',
				controller: 'contractInvokeController'
			})
			.when('/contractDel', {//contractDetail
				templateUrl: 'app/templates/contract/contract_del.html',
				controller: 'contractDelController'
			})
            .when('/blockchain/spvs', {//bcspvs
                templateUrl: 'app/templates/blockchain/bcsv.html',
                controller: 'bcsvController'
            })
            .when('/blockchain/chainlist',{
            	templateUrl: 'app/templates/blockchain/bcchainlist.html',
            	controller: 'bcchainlistController'
            })
            .when('/blockchain/endpoint', {//bcendpoint
                templateUrl: 'app/templates/blockchain/bcendpoint.html',
                controller: 'bcendpointController'
            })
            .when('/blockchain/config/detail', {//bcconfig
                templateUrl: 'app/templates/blockchain/bcconfig.html',
                controller: 'bcmanagerController'
            })
			.when('/blockchain/operation', {//bcoperation
				templateUrl: 'app/templates/blockchain/bcoperation.html',
				controller: 'bcoperationController'
			})
            .when('/blockchain/manager', {//bcmanager
                templateUrl: 'app/templates/blockchain/bcmanager.html',
                controller: 'bcmanagerController'
            })
			.when('/blockchain/view', {//bcview
				templateUrl: 'app/templates/blockchain/bcview.html',
				controller: 'bcviewController'
			})
			.when('/blockchain/viewdetail', {//bcviewdetail
				templateUrl: 'app/templates/blockchain/bcviewdetail.html',
				controller: 'bcviewdetailController'
			})
			.when('/user/modifyPassWord', {//bcviewdetail
				templateUrl: 'app/templates/layout/pwd_modify.html',
				controller: 'userController'
			})
			.when('/user/login', {
				templateUrl: 'app/templates/layout/login.html',
				controller: 'app'
			})
			// .when('/new', {
			// templateUrl: 'app/templates/new/new.html',
			// controller: 'newController'
			// })
			.otherwise({
				templateUrl: 'app/templates/summary/summary.html',
				controller: 'summaryController'
			})
	});

});