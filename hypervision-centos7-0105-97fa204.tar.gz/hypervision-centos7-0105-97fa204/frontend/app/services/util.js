define([
    'angular'
], function () {

    angular.module('services')
        .factory('util', [ function () {
            var _self = this;

            var isStrictAddress = function (address) {
                return /^0x[0-9a-f]{40}$/i.test(address);
            };
            var isArray = function (object) {
                return object instanceof Array;
            };
            _self.solidityTypeCheck=function (type, val) {
                if (val.replace(/(^\s*)|(\s*$)/g, '') == '') {
                    return 'empty'
                }
                if (type.indexOf("[") != -1 && !isArray(val)) {
                    // toastr.error("数组类型错误")
                    return ''
                } else if (type.indexOf('uint') != -1) {
                    if (isNaN(val)) {
                        return 'number'
                    } else if (Number(val) < 0) {
                        return 'uint'
                    }
                } else if (type.indexOf('int') != -1 && isNaN(val)) {
                    return 'number'
                } else if (type.indexOf('bool') != -1 && !(val == 'true' || val == 'false')) {
                    return 'bool'
                } else if (type.indexOf('address') != -1 && !isStrictAddress(val)) {
                    return 'address'
                } else if (type.indexOf("bytes") != -1) {
                    var temp = type.replace(/(^\s*)|(\s*$)/g, '')
                    var len = Number(temp.substring(5, temp.length))
                    if (len && len < val.length) {
                        return 'bytes'
                    }
                }
                return ''
            }
            // toogleSelect
            _self.toogleSelect = function (i,sc) {
                count=0
                i.check = !i.check;
                var isAllcheck = true;
                for (var i = 0; i < sc.result.length; i++) {
                    if(!sc.result[i].check){
                        isAllcheck = false;
                    }else{
                        count++
                    }
                }
                sc.selectall = isAllcheck;
                if(count){
                    sc.isSelect=true
                }else{
                    sc.isSelect=false
                }
                return sc.isSelect

            }
            // selectAll
            _self.selectall = false;
            _self.selectAll = function (sc) {
                sc.selectall = !sc.selectall;
                for (var i = 0; i < sc.result.length; i++) {
                    sc.result[i].check = sc.selectall;
                }
                if(sc.selectall){
                    return true
                }
                return false
            }
            _self.checkAddress = function(addr) {
                var AddressLength = 20

                // 去除两头空格
                var v_addr = addr.replace(/^\s+|\s+$/g,"");
                var r_addr = v_addr

                if (v_addr.length >= 2 && v_addr.slice(0,2) == "0x") {
                    r_addr = v_addr.slice(2)
                }
                if (r_addr.length != 2 * AddressLength ) {
                    return false
                }
                return true
            }
            _self.isEmpty = function(data) {

                var type = typeof data

                if (!data) {
                    return true
                }

                if (type === 'object') {
                    for (var k in data) {
                        if (!data[k]) {
                            return true
                        }
                    }
                }
                return false
            };

            _self.hex_to_ascii = function(str1){
                var hex  = str1.toString();
                var str = '';
                for (var n = 0; n < hex.length; n += 2) {
                    str += String.fromCharCode(parseInt(hex.substr(n, 2), 16));
                }
                str = str.replace(/\0/g, ''); // 去除\u0000
                return str;
            }

            _self.ascii_to_hex = function(pStr) {
                var tempstr = '';
                for (a = 0; a < pStr.length; a = a + 1) {
                    tempstr = tempstr + pStr.charCodeAt(a).toString(16);
                }
                return tempstr;
            }

            return _self;

        }
        ]);

});