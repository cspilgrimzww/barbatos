define([
    'angular',
    'toastr'
], function (ng, toastr) {
    angular.module('services')
        .factory('base', ['$http', '$location', '$translate', function ($http, $location, $translate) {
            var _this = this;
            this.api = 'http://localhost:8089/v2/';
            // this.api = 'http://121.196.208.4:8089/v2/';
            this.token = localStorage.getItem('token') || '';
            this.uptoken = 'Basic ' + window.btoa(this.token + ':');
            this.password = '';
            // 如果是Type 2,请求不必上传数据，直接请求url
            this.ajax = function (apiurl, method, data, type) {
                this.token = localStorage.getItem('token') || '';
                if(!this.token || this.token.length <= 0){
                    var fakeAjax = function () {
                        return this
                    };
                    fakeAjax.error = function () {
                        return null
                    };
                    fakeAjax.success = function () {
                        return null
                    };
                    return fakeAjax
                }
                this.uptoken = 'Basic ' + window.btoa(this.token + ':' + this.password);
                var uptoken = 'Basic ' + window.btoa(this.token + ':' + this.password);
                // console.log(this.token + ':' + this.password)
                var header = { 'Content-Type': 'application/json', 'Authorization': uptoken };
                if (type == 2) {
                    return $http({
                        method: method,
                        url: this.api + apiurl,
                        headers: header
                    }).error(function (data, state) {
                        if (data) {
                            toastr.remove();
                            toastr.error(data.msg || 'Error');
                        }
                    });
                } else {
                    if (method == 'get') {
                        var getinfo = data ? '?' : '';
                        for (var i in data) {
                            getinfo += i + '=' + data[i] + '&';
                        }
                        return $http({
                            method: 'GET',
                            headers: header,
                            url: this.api + apiurl + getinfo,
                        }).error(function (data, state) {
                            if (state == 401) {
                                localStorage.clear();
                                _this.token = '';
                                $location.url('/');
                                toastr.remove()
                                toastr.error(data.msg || $translate.instant('Common.Auth_Failed'));
                            } else {
                                //toastr.error('error:' + state);
                            }
                        });
                    } else {
                        return $http({
                            method: method,
                            url: this.api + apiurl,
                            headers: header,
                            data: data
                        }).error(function (data, state) {
                            if (state == 401) {
                                localStorage.clear();
                                _this.token = '';
                                $location.url('/');
                                toastr.remove()
                                toastr.error(data.msg || $translate.instant('Common.Auth_Failed'));
                            } else {
                                //toastr.error('error:' + state);
                            }
                            if (data) {
                                toastr.remove()
                                // toastr.error(data.msg || 'Error');
                            } else {
                                //toastr.error('Error:' + state);
                            }
                        });
                    }
                }
            };
            return {
                api: this.api,
                down: this.down,
                ajax: this.ajax,
                token: this.token,
                uptoken: this.uptoken,
                password: this.password
            }
        }
        ]);

});
