define([
    'angular'
], function () {
    angular.module('controllers').controller('serverDetailController', ['$scope', 'base', '$http', function ($scope, base, $http) {
        var s = $scope;
        s.total = 0;

        // 获取容器列表
        var hostIp = localStorage.getItem('hostIp');
        s.getlist = function () {
            base.ajax('chain/container', 'get', { search: hostIp }).success(function (data) {
                s.total = data.count;
                s.result = data.containers;
            });
        }
        s.getlist();
    }]);
});