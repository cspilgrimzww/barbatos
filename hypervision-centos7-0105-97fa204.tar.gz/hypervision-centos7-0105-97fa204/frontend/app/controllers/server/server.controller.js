define([
    'angular',
    'jquery',
    'toastr',
    'SweetAlert',
], function (ng, $, toastr){
     var serverController = function ($scope, util, base, $http, $interval, $location) {
        var _self = this;

        $scope.isSelect=false;
        $scope.IpTip=false;
         $scope.handlePatternIP = (function() {
             var regex = /((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))/;
             return {
                 test: function(value) {
                     r=regex.test(value)
                     if(r.toString()=="false"){
                         $scope.IpTip=false
                     }else{
                         $scope.IpTip=true
                     }
                     return regex.test(value);
                 }
             };
         })();

        $.extend(_self, util);
        _self.serverList = {};//add server
        _self.page = {
            pageSize: 15,
            index: 1,
            count: 0
        };
        search();//get server main list
        $interval(function () {
            if (_self.searchStatus == '' && $location.$$url == '/server') {
                search('interval');
            }
        }, 3000);
        _self.add = {
            show: false,//modal
            addServer: function () {
                this.show = true;
                _self.stIP = "";
                _self.endIP = "";
                resetAdd();
            }
        };
        _self.viewDetail = function (ip) {
            localStorage.setItem('hostIp', ip);
            window.location.href = '#/server/detail'
        };
        _self.searchStatus = '';//search condition
        _self.select = function (status) {
            _self.searchStatus = status;
            _self.keyword = "";
            base.ajax('servers', 'get', {
                status: status,
                pageSize: _self.page.pageSize,
                index: _self.page.index
            }).success(function (data) {
                _self.result = data.hosts;
                _self.page.count = data.count
            });
        };
        // 排序
        _self.s1 = false;
        _self.s2 = false;
        _self.s3 = false;
        _self.reverse = function (sort, x) {
            if (x == 1) {
                _self.s1 = !_self.s1;
            } else if (x == 2) {
                _self.s2 = !_self.s2;
            } else if (x == 3) {
                _self.s3 = !_self.s3;
            }
            if (sort == _self.sort) {
                _self.sort = "-" + sort;
            } else {
                _self.sort = sort;
            }
            search();
        };
        var t;
        _self.searchKeyup = function () {
            search();
        };

        function search(type) {
            base.ajax('servers', 'get', {
                sorter: _self.sort || '',
                search: _self.keyword || '',
                pageSize: _self.page.pageSize,
                index: _self.page.index
            }).success(function (data) {
                if (data.hosts == undefined) {
                    data.hosts = []
                }
                if (type == 'interval') {
                    _self.result.forEach(function (item) {
                        data.hosts.forEach(function (host) {
                            if (host.hostName == item.hostName){
                                item.status = host.status;
                                item.ip = host.ip;
                                item.mem = Math.ceil(host.mem.substring(0, 2)/10) + "G";
                                item.cpu = host.cpu + ' Core';
                                item.containerCount = host.containerCount
                            }
                        })
                    })
                } else {
                    _self.result = data.hosts;
                    _self.page.count = data.count;
                    _self.result.forEach(function (item) {
                        data.hosts.forEach(function (host) {
                            if (host.hostName == item.hostName){
                                item.status = host.status;
                                item.ip = host.ip;
                                item.mem = Math.ceil(host.mem.substring(0, 2)/10) + "G";
                                item.cpu = host.cpu + ' Core';
                                item.containerCount = host.containerCount
                            }
                        })
                    })
                }
                if(data.hosts.length == 0){
                    _self.selectall = false;
                }

            });
        };

        _self.goPage = function (page) {
            _self.page.index = page;
            search();
        }


        _self.getServerList = function () {

            var startTime = new Date().getTime();

            var regex = /((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))/;

            if(_self.stIP=='' || _self.endIP==''||!regex.test(_self.stIP)||!regex.test(_self.endIP)){
                toastr.warning("请输入IP范围");
                return;
            }

            var search = swal({
                title: "正在搜索中...",
                text: "请等待...",
                type: "warning",
                showCancelButton: false,
                showConfirmButton: false
            });

            base.ajax('servers', 'get', { from: _self.stIP, to: _self.endIP }).success(function (data) {
                if (data.hosts == undefined) {
                     data.hosts = []
                }
                _self.serverList.result = data.hosts.filter(function (item) {
                    return item.status == "Available"
                });
                _self.serverList.refused = data.hosts.filter(function (item) {
                    return item.status != "Available"
                });
                _self.serverList.selectall = true;
                if (data.hosts.length > 0) {
                    $.each(data.hosts, function (i, host) {
                        host.check = true;
                    })
                }
                if (_self.serverList.result.length == 0) {
                    swal({
                        title: "搜索完成",
                        text: "未搜索到可用服务器",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#69b1d2"
                    });
                } else if (_self.serverList.result.length > 0 ) {
                    swal({
                        title: "搜索完成!",
                        text: "",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#69b1d2"
                    });
                } else {
                    swal({
                        title: "搜索完成",
                        text: "未搜索到可用服务器",
                        type: "success",
                        showCancelButton: false,
                        confirmButtonColor: "#69b1d2"
                    });
                }
            }).error(function(err){
                //todo 第一个参数是error吗？？
                console.log(err)
                swal({
                    title: "搜索失败",
                    // text: JSON.stringify(err),
                    type: "error",
                    confirmButtonColor: "#69b1d2"
                });
            });
        };
        _self.delete = function (id) {
            var ids = [];
            // var result= confirm("你确定要删除吗？")
            // if(!result) {
            //     return
            // }
            var existContainer = 0
            if (!!id) {
                ids.push(id);
            } else {
                $.each(_self.result, function (i, item) {
                    existContainer = item.containerCount.run + item.containerCount.ready + item.containerCount.disabled + item.containerCount.pending
                    if (item.check) {
                        ids.push(item._id);
                    }
                })
            }
            if (existContainer > 0){
                swal({
                    title: "请先删除该服务器上的容器",
                    type: "warning",
                    showCancelButton: false,
                    confirmButtonColor: "#69b1d2"
                });
            } else {

                swal({
                        title: "确定删除吗?",
                        text: "将会删除选中的服务器!",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        closeOnConfirm: false,
                        closeOnCancel: true
                    },
                    function (isConfirm) {
                        if (isConfirm) {
                            if (ids.length != 0) {
                                swal({
                                    title: "正在删除中...",
                                    text: "请等待...",
                                    type: "warning",
                                    showCancelButton: false,
                                    showConfirmButton: false
                                });
                                base.ajax('servers', 'delete', { ids: ids }).success(function (data) {
                                    search();
                                    swal({
                                        title: "删除成功",
                                        text: "服务器删除成功",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonColor: "#69b1d2"
                                    });
                                }).error(function (data) {
                                    swal({
                                        title: "删除失败",
                                        text: data.msg,
                                        type: "error",
                                        showCancelButton: false,
                                        confirmButtonColor: "#69b1d2"
                                    })
                                });
                            } else {
                                swal({
                                    title: "删除失败",
                                    text: "请选择一个服务器",
                                    type: "error",
                                    showCancelButton: false,
                                    confirmButtonColor: "#69b1d2"
                                });
                            }
                        } else {
                            swal({
                                title: "取消成功",
                                text: ":)",
                                type: "success",
                                showCancelButton: false,
                                confirmButtonColor: "#69b1d2"
                            });
                        }
                    }
                );
            }

        };

        _self.addArr = [true, false];
        _self.switchStatus = function (i) {
            var arr = [false, false];
            arr[i] = true;
            _self.addArr = arr;
        };
        _self.serverDeploy = function () {
            var ids = [];
            $.each(_self.serverList.result, function (i, list) {
                if (list.check) {
                    ids.push(list._id);
                }
            });
            if (ids.length > 0) {
                base.ajax('servers/minion', 'post', { ids: ids }).success(function (data) {
                    _self.result = data.hosts;
                    search();
                    toastr.success('请求成功，安装中');
                });
                _self.add.show = false;
            } else {
                toastr.error('请选择服务器');
            }

        };

        function resetAdd() {
            $scope.stIp = "";
            $scope.endIp = "";
            _self.serverList = {};
        };

        //---------------------------tooltip start-----------------------------------
        _self.ToolTip = {
            ShowTip: function (e, item) {
                var target = e.target;
                if (item.containerCount.stopped == undefined) {
                    item.containerCount.stopped = 0
                }
                if ($(e.target).find("#tipPanel").length == 0 && $(e.target).closest('td').find("#tipPanel").length == 0) {
                    var _tipPanel = '<div class="tooltip" id="tipPanel">' +
                        '<ul><li><label>Running</label> <i class="circle green">' + item.containerCount.run +
                        '</i></li>' +
                        '<li><label>Ready</label> <i class="circle blue">' + item.containerCount.ready +
                        '</i></li>' +
                        '<li><label>Stopped</label> <i class="circle red">' + item.containerCount.stopped +
                        '</i></li>' +
                        '<li><label>Unknow</label> <i class="circle grey">' + item.containerCount.unknown +
                        '</i></li></ul><div class="triangle"></div>' +
                        '</div>';
                    $(target).append(_tipPanel);
                }
            },
            HideTip: function (e) {
                $(e.target).find("#tipPanel").remove();
                $(e.target).closest('td').find("#tipPanel").remove();
            }
        };

    };
    angular.module('controllers').controller('serverController', [
        '$scope', 'util', 'base', '$http', '$interval', '$location', serverController
    ]);

});