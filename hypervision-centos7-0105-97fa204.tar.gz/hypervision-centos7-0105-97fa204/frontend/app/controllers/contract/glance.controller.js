define([
    'angular',
    'toastr',
    'SweetAlert'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('contractGlanceController', ['$scope', '$window', '$http', 'base', '$translate', function ($scope, $window, $http, base, $translate) {
        var s = $scope;
        var id = localStorage.getItem('p_id');
        var name = localStorage.getItem('c_name');
        var contract_glance = JSON.parse(localStorage.getItem('contracts_glance'));
        s.first = 1;

        s.result_hide = true;
        s.haveData = true;
        s.hasName = true;
        s.modal1 = false;
        s.used = {
            privateKey: '',
            confirm: false
        };
        s.pk = '';
        s.returnUrl = "#/project/contract/" + contract_glance.id;
        s.functionList = [];

        s.name = contract_glance.name;
        s.variable_hide = true;
        s.transaction_hide = false;
        s.function_hide = true;

        s.pkFileName = "";
        s.page = {currentPage : 1};

        var clearVariableContent = function() {
            s.resultList = [];
            s.headList = [];
            s.headList1 = [];
        };
        clearVariableContent();
        s.showVariableTab = function () {
            clearVariableContent();
            s.variable_hide = false;
            s.transaction_hide = true;
            s.function_hide = true;
            s.modal1 = true;
        };
        s.showTransactionTab = function () {
            s.variable_hide = true;
            s.transaction_hide = false;
            s.function_hide = true;
        };
        s.showFunctionTab = function () {
            s.variable_hide = true;
            s.transaction_hide = true;
            s.function_hide = false;
        };

        /*上传私钥,the localstorage will save one copy*/

        s.privKeyfile = function (file) {
            s.used.confirm = false;
            s.file = $(file)[0].files[0];
            $(file).siblings().html(s.file.name)
            s.pkFileName = s.file.name
            var reader = new FileReader();
            reader.onload = function () {
                len = this.result.length;
                if (this.result.slice(len-1, len).charCodeAt() < 32){
                    s.used.privateKey = this.result.slice(0,len-1);
                }else{
                    s.used.privateKey = this.result
                }
                if (s.used.privateKey == ""){
                    toastr.warning("私钥为空!");
                    return
                }
                s.$apply();
            }
            reader.readAsText(s.file);

        }
        /*get variables*/
        s.variableSetAH = [];
        s.variableSetIQ = [];
        s.variableSetRZ = [];
        s.variableMap = {};
        s.typeTwoSet = [];
        //variable
        var varPattaAH0 = new RegExp(/get([a-h]|[A-H])[\w]*Map(Part[0-9]+)*Ref[\w]*/);
        var varPattaIQ0 = new RegExp(/get([i-q]|[I-Q])[\w]*Map(Part[0-9]+)*Ref[\w]*/);
        var varPattaRZ0 = new RegExp(/get([r-z]|[R-Z])[\w]*Map(Part[0-9]+)*Ref[\w]*/);
        var varPatt1 = new RegExp(/get[\w]*Map(Part[0-9]+)*Ref[\w]*And[\w]*/);
        var varPatt2 = new RegExp(/getSizeRef[\w]*/);
        //functions
        s.funSetAH = []
        s.funSetIQ = []
        s.funSetRZ = []
        var funPattaAH = new RegExp(/^([a-h]|[A-H])[\w]*/);
        var funPattaIQ = new RegExp(/^([i-q]|[I-Q])[\w]*/);
        var funPattaRZ = new RegExp(/^([r-z]|[R-Z])[\w]*/);

        var thisAbi = JSON.parse(contract_glance.abi);
        for (var i = 0; i < thisAbi.length; i++) {
            if (funPattaAH.test(thisAbi[i].name)) {
                s.funSetAH.push(thisAbi[i].name);
                continue;
            }
            if (funPattaIQ.test(thisAbi[i].name)) {
                s.funSetIQ.push(thisAbi[i].name);
                continue;
            }
            if (funPattaRZ.test(thisAbi[i].name)) {
                s.funSetRZ.push(thisAbi[i].name);
                continue;
            }
        }

        for (var i = 0; i < thisAbi.length; i++) {
            var tempData = "";
            if (varPatt2.test(thisAbi[i].name)) {
                tempData = thisAbi[i].name.match(/getSizeRef(\w*)/)[1];
                s.typeTwoSet.push(tempData);
            }
        }
        for (var i = 0; i < thisAbi.length; i++) {
            var tempData = "";
            if (varPattaAH0.test(thisAbi[i].name)) {
                if (varPatt1.test(thisAbi[i].name))
                    continue;
                tempData = thisAbi[i].name.match(/get(\w*)Map/)[1];
                if (s.typeTwoSet.indexOf(tempData) != -1)
                    continue;
                if (s.variableSetAH.indexOf(tempData) == -1) {
                    s.variableSetAH.push(tempData);
                    s.variableMap[tempData] = [];
                    s.variableMap[tempData].push(i);
                }
                else {
                    s.variableMap[tempData].push(i);
                }
            }
            if (varPattaIQ0.test(thisAbi[i].name)) {
                if (varPatt1.test(thisAbi[i].name))
                    continue;
                tempData = thisAbi[i].name.match(/get(\w*)Map/)[1];
                if (s.typeTwoSet.indexOf(tempData) != -1)
                    continue;
                if (s.variableSetIQ.indexOf(tempData) == -1) {
                    s.variableSetIQ.push(tempData);
                    s.variableMap[tempData] = [];
                    s.variableMap[tempData].push(i);
                }
                else {
                    s.variableMap[tempData].push(i);
                }
            }
            if (varPattaRZ0.test(thisAbi[i].name)) {
                if (varPatt1.test(thisAbi[i].name))
                    continue;
                tempData = thisAbi[i].name.match(/get(\w*)Map/)[1];
                if (s.typeTwoSet.indexOf(tempData) != -1)
                    continue;
                if (s.variableSetRZ.indexOf(tempData) == -1) {
                    s.variableSetRZ.push(tempData);
                    s.variableMap[tempData] = [];
                    s.variableMap[tempData].push(i);
                }
                else {
                    s.variableMap[tempData].push(i);
                }
            }
        }

        s.paramData = {
            encrypted: false,
            password: ""
        };

        s.confirm = function () {
            if (!s.used.privateKey || s.used.privateKey.replace(/(^\s*)|(\s*$)/g, '') == '') {
                toastr.error($translate.instant("Chain.config.ImportPrivKey"));
                return;
            }

            if (s.paramData.encrypted && s.paramData.password == "") {
                toastr.warning("密码不能为空！")
                return
            }
            if (!s.paramData.encrypted) {
                s.paramData.password = ""
            }

            s.used.confirm = true;
            localStorage.setItem("pK", s.used.privateKey)
            localStorage.setItem("pkFileName", s.file.name)
            s.modal1 = false;
        };

        s.sortByCol = function (name) {
            s.col = name;
            s.desc = !s.desc;
            console.log(s.col);
        };

        var dataToShow = function (types, result) {
            if (result instanceof Array) {
                var i = 0   // i 表示返回参数的位置
                for (; i < result.length; i++) {
                    if (result[i] instanceof Array) {
                        var j = 0;  // j 表示返回的参数是数组的话，j就是其索引
                        for (; j < result[i].length; j++) {
                            if (types[i].indexOf("byte") == 0) {
                                result[i][j] = s.parseBytesData(result[i][j]);
                            }
                        }
                    } else {
                        if (types.length == 1) {
                            if (types[0].indexOf("byte") == 0) {
                                result[i] = s.parseBytesData(result[i]);
                            } else if (i == result.length - 1) {
                                var new_arr = [];
                                new_arr.push(result == null ? "" : result);
                                return new_arr;
                            }
                        } else if (types[i].indexOf("byte") == 0) {
                            result[i] = s.parseBytesData(result[i]);
                        }

                    }
                }
            } else {
                var result_arr = [];
                if (types.length > 0 && types[0].indexOf("byte") == 0) {
                    result = s.parseBytesData(result);
                }
                result_arr.push(result);
                return result_arr;
            }
            return result;
        }

        s.toDetail = function (funcName, item) {
            swal({
                title: $translate.instant("Common.Querying"),
                text: $translate.instant("Common.Waiting"),
                type: "warning",
                showCancelButton: false,
                showConfirmButton: false
            });
            s.haveData = true;
            var out_types = [];
            var callFunctionObj = [];
            for (var i = 0; i < thisAbi.length; i++) {
                if (thisAbi[i].name.indexOf('get' + funcName) != -1) {
                    var updata = {
                        id: id,
                        contractName: name,
                        methodName: "",
                        privateKey: s.used.privateKey,
                        constant: true,
                        callMethod: [],
                        password: s.paramData.password
                    }
                    if (thisAbi[i].name.indexOf('And') != -1) {
                        updata.methodParams = [item, '0', '0'];
                        updata.methodName = thisAbi[i].name;
                        var tempFunc = thisAbi[i];
                        var tempName = thisAbi[i].name.replace(/get(\w*)Ref/, "");
                        var tempName = tempName.replace(/And(\w*)Array/, "");
                        var tempName = "get" + tempName + "Map";
                        out_types.push('bytes32');
                        for (var j = 0; j < thisAbi.length; j++) {
                            if (thisAbi[j].name.indexOf(tempName) != -1) {
                                callFunctionObj.push(thisAbi[j]);
                                updata['callMethod'].push(thisAbi[j].name);
                            }
                        }
                        for (var k = 0; k < callFunctionObj.length; k++) {
                            for (var j = 0; j < callFunctionObj[k].outputs.length; j++) {
                                out_types.push(callFunctionObj[k].outputs[j].type);
                            }
                        }
                        base.ajax('projects/contracts/refdetail', 'post', updata).success(function (data) {
                            clearVariableContent();
                            s.hasName = true;
                            s.headList.push({name: 'pid'});
                            for (var i = 0; i < callFunctionObj.length; i++) {
                                s.headList = s.headList.concat(callFunctionObj[i].outputs);
                            }
                            for (var i = 0; i < data.result.length; i++) {
                                var newdata = dataToShow(out_types, data.result[i]);
                                var tempMap = {};
                                for (var j = 0; j < s.headList.length; j++) {
                                    tempMap[s.headList[j].name] = newdata[j];
                                }
                                s.resultList.push(tempMap);
                            }
                            if (s.resultList.length == 0) {
                                s.haveData = false;
                            }
                            s.col = s.headList[0].name;
                            s.desc = 0;
                            s.result_hide = false;
                            //toastr.success($translate.instant("Common.Success"));
                            swal({
                                title: $translate.instant("Common.Success"),
                                type: "success",
                                customClass: 'swal-wide',
                                confirmButtonColor: "#69b1d2"
                            });
                        }).error(function (data) {
                            clearVariableContent();
                            swal({
                                title: $translate.instant("Common.Failed"),
                                text: data.msg,
                                type: "error"
                            });
                            if (!data.msg && data.msg == "RangeError: private key length is invalid") {
                                s.used.privateKey = "";
                                localStorage.removeItem("pK");
                            }
                        });
                    }
                    else {
                        updata.methodParams = [item, "0"];
                        updata.sizeParams = [item];

                        for (var j = 0; j < thisAbi.length; j++) {
                            if (thisAbi[j].name.indexOf("getSizeRef" + funcName) != -1) {
                                updata['methodName'] = thisAbi[j].name;
                            }
                            if (thisAbi[j].name.indexOf("get" + funcName) != -1) {
                                callFunctionObj.push(thisAbi[j]);
                                updata["callMethod"].push(thisAbi[j].name);
                            }
                        }
                        for (var k = 0; k < callFunctionObj.length; k++) {
                            for (var j = 0; j < callFunctionObj[k].outputs.length; j++) {
                                out_types.push(callFunctionObj[k].outputs[j].type);
                            }
                        }
                        base.ajax('projects/contracts/sizedetail', 'post', updata).success(function (data) {
                            clearVariableContent();
                            s.hasName = false;
                            for (var i = 0; i < callFunctionObj.length; i++) {
                                s.headList = s.headList.concat(callFunctionObj[i].outputs);
                            }
                            for (var i = 0; i < data.result.length; i++) {
                                var newdata = dataToShow(out_types, data.result[i]);
                                var tempMap = {};
                                for (var j = 0; j < s.headList.length; j++) {
                                    tempMap[s.headList[j].name] = newdata[j];
                                }
                                s.resultList.push(tempMap);
                            }
                            if (s.resultList.length == 0) {
                                s.haveData = false;
                            }
                            s.col = s.headList[0].name;
                            s.desc = 0;
                            s.result_hide = false;
                            //toastr.success($translate.instant("Common.Success"));
                            swal({
                                title: $translate.instant("Common.Success"),
                                type: "success",
                                customClass: 'swal-wide',
                                confirmButtonColor: "#69b1d2"
                            });

                        }).error(function (data) {
                            clearVariableContent();
                            if (!data.msg && data.msg == "RangeError: private key length is invalid") {
                                s.used.privateKey = "";
                                localStorage.removeItem("pK");
                            }
                        });
                    }
                }
            }
        };
        s.showVariable = function (vName) {
            if(!s.used.confirm){
                swal({
                    title: "私钥",
                    text: "请先上传私钥!",
                    type: "warning",
                    confirmButtonText: $translate.instant("Common.Confirm"),
                    cancelButtonText: $translate.instant("Common.Cancel"),
                    showCancelButton: true,
                    showConfirmButton: true,
                    closeOnCancel: true
                },function(isConfirm){
                    if (isConfirm) {
                        s.modal1 = true;
                    }
                });
                return
            }
            swal({
                title: $translate.instant("Common.Querying"),
                text: $translate.instant("Common.Waiting"),
                type: "warning",
                showCancelButton: false,
                showConfirmButton: false
            });
            var callFunctionObj = [];
            for (var i = 0; i < s.variableMap[vName].length; i++) {
                callFunctionObj.push(thisAbi[s.variableMap[vName][i]]);
            }
            var refName = callFunctionObj[0].name.match(/Ref(\w*)/)[1];
            var refFunctionName = "get" + refName + "List";
            var refFunction = undefined;
            var refList = [];
            for (var i = 0; i < thisAbi.length; i++) {
                if (thisAbi[i].name == refFunctionName) {
                    refFunction = thisAbi[i];
                    continue;
                }
                if (thisAbi[i].name.indexOf(refName) > 0 && thisAbi[i].name.indexOf('get' + vName) == -1 && thisAbi[i].name.indexOf('set') == -1) {
                    refList.push(thisAbi[i]);
                }
            }
            var out_types = [];
            var call_method = [];
            out_types.push('bytes32');
            for (var i = 0; i < callFunctionObj.length; i++) {
                for (var j = 0; j < callFunctionObj[i].outputs.length; j++) {
                    out_types.push(callFunctionObj[i].outputs[j].type);
                }
                call_method.push(callFunctionObj[i].name);
            }
            var updata = {
                id: id,
                contractName: name,
                methodName: refFunctionName,
                methodParams: ['0', '0'],
                //constant: s.selectFunction.constant,
                privateKey: s.used.privateKey,
                constant: true,
                callMethod: call_method,
                password: s.paramData.password
            };
            s.haveData = true;
            base.ajax('projects/contracts/variablescan', 'post', updata).success(function (data) {
                clearVariableContent();
                s.hasName = true;
                s.headList.push({name: 'pid'});
                for (var i = 0; i < callFunctionObj.length; i++) {
                    s.headList = s.headList.concat(callFunctionObj[i].outputs);
                }
                for (var i = 0; i < refList.length; i++) {
                    var tempHead = refList[i].name.match(/get(\w*)(List)*Map/)[1];
                    s.headList1.push(tempHead);
                }
                for (var i = 0; i < data.result.length; i++) {
                    var newdata = dataToShow(out_types, data.result[i]);
                    var tempMap = {};
                    for (var j = 0; j < s.headList.length; j++) {
                        tempMap[s.headList[j].name] = newdata[j];
                    }
                    s.resultList.push(tempMap);
                }
                if (s.resultList.length == 0) {
                    s.haveData = false;
                }
                s.col = s.headList[0].name;
                s.desc = 0;
                s.result_hide = false;
                //toastr.success($translate.instant("Common.Success"));
                swal({
                    title: $translate.instant("Common.Success"),
                    type: "success",
                    customClass: 'swal-wide',
                    confirmButtonColor: "#69b1d2"
                });
            }).error(function (data) {
                clearVariableContent();
                var pKError = false;
                if (data.msg == "RangeError: private key length is invalid" || data.msg.indexOf("invalid private key") != -1 || data.msg.indexOf("Invalid address length")!=-1){
                    data.msg = "私钥错误,请重新上传!\n上传之后,可重新查询.";
                    pKError = true;
                }
                swal({
                    title: $translate.instant("Common.Failed"),
                    text: data.msg,
                    type: "error"
                },
                function(){
                        if (pKError) {
                            s.used.privateKey = "";
                            localStorage.removeItem("pK");
                            s.modal1 = true;
                        }
                });
            });
        }

        s.parseBytesData = function (data) {
            data = data == null ? "" : decodeURIComponent(escape(window.atob(data)));
            return data.replace(/\0/g, '');
        }

        s.transactionList = {}
        s.funTxList = {}
        s.transaction = {};
        s.function = {};
        s.pageSize = 15;
        s.blkRange = {}
        s.methodName = "";

        s.showFunctionContent = function (methodName) {
            s.page.currentPage = 1;
            s.methodName = methodName;
            getTransactionList()
        }


        s.showTransactionContent = function () {
            s.page.currentPage = 1;
            s.methodName = "";
            getTransactionList();
        };

        var getTransactionList = function () {
            if (s.blkRange.from == undefined || s.blkRange.to == undefined || s.blkRange.from == null || s.blkRange.to == null) {
                toastr.warning("区块号区间不能为空")
                return;
            }
            if (s.blkRange.from <= 0 || s.blkRange.to <= 0) {
                toastr.warning("区块号区间不能<=0")
                return;
            } else if (s.blkRange.to < s.blkRange.from) {
                toastr.warning("后一项区块号不能小于前一项")
                return;
            }
            swal({
                title: $translate.instant("Common.Querying"),
                text: $translate.instant("Common.Querying"),
                type: "info",
                showCancelButton: false,
                showConfirmButton: false
            })
            var data = {
                id: id,
                address: contract_glance.address,
                pageSize: s.pageSize,
                name: name,
                from: s.blkRange.from,
                to: s.blkRange.to,
                methodName: s.methodName
            };
            base.ajax('projects/contracts/transactions/first', 'get', data).success(function (data) {
                if (s.methodName == "") {
                    s.transactionList = data.list;
                    s.transaction.total = data.count;
                    s.transaction.page = 1;
                } else {
                    s.funTxList = data.list;
                    s.function.total = data.count;
                    s.function.page = 1;
                }
                for (i = 0; i < data.list.length; i++) {
                    tx = data.list[i];
                    tx.methodDetail = decodeMethod(tx.methodName, tx.inputValues, tx.outputValues);
                }
                swal.close();
            }).error(function (data) {
                swal({
                    title: $translate.instant("Common.Failed"),
                    text: data.msg,
                    type: "error"
                })
            });
        }

        s.goFuncPage = function (page) {
            var txs, url, separated;
            if (page > s.function.page) {
                txs = s.funTxList[s.funTxList.length - 1];
                separated = (page - s.function.page - 1) * s.pageSize;
                url = 'projects/contracts/transactions/next'
            } else if (page < s.function.page) {
                txs = s.funTxList[0];
                url = 'projects/contracts/transactions/prev';
                separated = (s.function.page - page - 1) * s.pageSize
            } else {
                return
            }
            var data = {
                id: id,
                blkNumber: txs.blockNumber,
                txIndex: txs.txIndex,
                separated: separated,
                pageSize: s.pageSize,
                address: contract_glance.address,
                contractName: name,
                from: s.blkRange.from,
                to: s.blkRange.to,
                methodName: s.methodName
            };
            base.ajax(url, 'get', data).success(function (data) {
                s.funTxList = data;
                for (i = 0; i < data.length; i++) {
                    tx = data[i];
                    tx.methodDetail = decodeMethod(tx.methodName, tx.inputValues, tx.outputValues);
                }
            }).error(function (data) {
                toastr.error(data.msg);
            });
            s.function.page = page;
        }

        s.goTxPage = function (page) {
            var txs, url, separated;
            if (page > s.transaction.page) {
                txs = s.transactionList[s.transactionList.length - 1];
                separated = (page - s.transaction.page - 1) * s.pageSize;
                url = 'projects/contracts/transactions/next'
            } else if (page < s.transaction.page) {
                txs = s.transactionList[0];
                url = 'projects/contracts/transactions/prev';
                separated = (s.transaction.page - page - 1) * s.pageSize
            } else {
                return
            }
            var data = {
                id: id,
                blkNumber: txs.blockNumber,
                txIndex: txs.txIndex,
                separated: separated,
                pageSize: s.pageSize,
                address: contract_glance.address,
                contractName: name,
                from: s.blkRange.from,
                to: s.blkRange.to,
                methodName: ""
            };
            base.ajax(url, 'get', data).success(function (data) {
                s.transactionList = data;
                for (i = 0; i < data.length; i++) {
                    tx = data[i];
                    tx.methodDetail = decodeMethod(tx.methodName, tx.inputValues, tx.outputValues);
                }
            }).error(function (data) {
                toastr.error(data.msg);
            });
            s.transaction.page = page;
        }

        var parseByte = function (origin, type) {
            if (origin instanceof Array) {
                var x = 0;  // j 表示返回的参数是数组的话，j就是其索引
                for (; x < origin.length; x++) {
                    if (type.indexOf("byte") == 0) {
                        origin[x] = s.parseBytesData(origin[x])
                    }
                }
            } else {
                if (type.indexOf("byte") == 0) {
                    origin = s.parseBytesData(origin)
                }
            }
            return origin
        }

        var decodeMethod = function (methodName, inputs, outputs) {
            for (var i = 0; i < thisAbi.length; i++) {
                var method = thisAbi[i];
                if (method.name == methodName || (methodName == "DEPLOY" && method.name == "")) {
                    var detailData = {};
                    var inputRes = []
                    var outputRes = []
                    for (var j = 0; j < method.inputs.length; j++) {
                        var data = {
                            name: method.inputs[j].name == "" ? "args[" + j + "]" : method.inputs[j].name,
                            value: parseByte(method.inputs.length == 1 ? inputs : inputs[j], method.inputs[j].type)
                        };
                        inputRes.push(data);
                    }
                    detailData.inputs = inputRes;

                    if (method.outputs != null) {
                        for (var j = 0; j < method.outputs.length; j++) {
                            var data = {
                                name: method.outputs[j].name == "" ? "returns[" + j + "]" : method.outputs[j].name,
                                value: parseByte(method.outputs.length == 1 ? outputs : outputs[j], method.outputs[j].type)
                            };
                            outputRes.push(data);
                        }
                    }
                    detailData.outputs = outputRes;
                    return detailData;
                }
            }
        }

        s.modal2 = false;
        s.showMethodDetail = function (transaction) {
            s.modal2 = true;
            s.tx = transaction;
        }
        s.closeModal2 = function () {
            s.modal2 = false
        }

        var defaultLimit = 5;
        s.funAHLimit = s.funSetAH.length <= defaultLimit ? s.funSetAH.length : defaultLimit;
        s.showFunAHLimitMore = function () {
            s.funAHLimit = s.funSetAH.length
        }

        s.funIQLimit = s.funSetIQ.length <= defaultLimit ? s.funSetIQ.length : defaultLimit;
        s.showFunIQLimitMore = function () {
            s.funIQLimit = s.funSetIQ.length;
        }

        s.funRZLimit = s.funSetRZ.length <= defaultLimit ? s.funSetRZ.length : defaultLimit;
        s.showFunRZLimitMore = function () {
            s.funRZLimit = s.funSetRZ.length;
        }
    }
    ]);
});