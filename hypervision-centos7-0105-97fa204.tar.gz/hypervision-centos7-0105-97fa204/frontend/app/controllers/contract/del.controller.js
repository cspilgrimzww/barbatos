define([
    'angular',
    'toastr',
    'SweetAlert'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('contractDelController', ['$scope', '$http', '$translate', 'base', function ($scope, $http, $translate, base) {
        var s = $scope;
        s.pageSize = 15;
        s.total = 0;
        s.pageNum = 1;

        s.getresult = function () {
            s.delist = [];
            s.selectlist = [];
            var update = {
                pageSize: s.pageSize,
                index: s.pageNum
            };
            base.ajax('projects', 'get', update).success(function (data) {
                s.total = data.count;
                s.result = data.projects;
                if(!data.projects|| data.projects.length == 0) {
                    window.location.href = '#/contract'
                }
                for (var i = 0; i < data.projects.length; i++) {
                    s.selectlist.push(false);
                    s.delist.push('');
                    s.result[i].type = $translate.instant("Common."+data.projects[i].type);
                    var status;
                    deployedContracts = data.projects[i].contracts.filter(function (item) {
                        return item.address != ""
                    });
                    console.log(deployedContracts);
                    console.log(deployedContracts.length);
                    switch(data.projects[i].contracts.length - deployedContracts.length){
                        case 0:
                            status = 'deployed';
                            break;
                        case data.projects[i].contracts.length:
                            status = 'undeployed';
                            break;
                        default:
                            status = 'partial'
                    }

                    s.result[i].status = $translate.instant("CONTRACT." + status)
                }
            });
        };

        s.goPage = function (page) {
            s.pageNum = page;
            s.getresult();
        }

        s.getresult();
        // 选择一个
        s.selItem = function (i, id) {
            s.selectlist[i] = !s.selectlist[i];
            s.selectlist[i] ? s.delist[i] = id : s.delist[i] = '';
            var flag = true;
            for (var i = 0; i < s.selectlist.length; i++) {
                if (!s.selectlist[i]) {
                    flag = false;
                    break
                }
            }
            flag ? s.allstatus = true : s.allstatus = false;

        }
        //全部选中
        s.allstatus = false;
        s.selAll = function () {
            s.allstatus = !s.allstatus;
            s.selectlist = [];
            s.delist = [];
            for (var i = 0; i < s.result.length; i++) {
                s.selectlist.push(s.allstatus);
                if (s.allstatus) {
                    s.delist.push(s.result[i]._id);
                } else {
                    s.delist.push('');
                }
            }
        }

        s.continue = function () {
            swal({
                    title: $translate.instant("Common.QueryConfirmDelete"),
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: $translate.instant("Common.Confirm"),
                    cancelButtonText: $translate.instant("Common.Cancel"),
                    closeOnConfirm: false,
                    closeOnCancel: true
                },
                function (isConfirm) {
                    if (isConfirm) {

                        var ids = [];
                        for (var i = 0; i < s.delist.length; i++) {
                            if (s.delist[i] != '') {
                                ids.push(s.delist[i]);
                            }
                        }
                        if (ids.length != 0) {
                            $http({
                                method: 'DELETE',
                                url: base.api + 'projects',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Authorization': base.uptoken
                                },
                                data: {
                                    ids: ids
                                }
                            }).success(function (data) {
                                s.allstatus = false;
                                swal(
                                    $translate.instant("Common.Delete_Success"),
                                    $translate.instant("CONTRACT.delete.Contract_Deleted"),
                                    "success"
                                );
                                s.getresult();
                            })
                        } else {
                            swal(
                                $translate.instant("Common.Delete_Failed"),
                                $translate.instant("CONTRACT.delete.ChooseOne"), "error");
                        }
                    } else {
                        swal($translate.instant("Common.Canceled"), ":)", "success");
                    }
                }
            );


        }
    }
    ]);
});