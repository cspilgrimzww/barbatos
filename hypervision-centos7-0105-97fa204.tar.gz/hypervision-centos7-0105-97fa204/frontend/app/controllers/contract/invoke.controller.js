define([
    'angular',
    'toastr'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('contractInvokeController', ['$scope', '$http', 'base', '$translate','util',function (s, $http, base,$translate,util) {
        var id = localStorage.getItem('p_id');
        var name = localStorage.getItem('c_name');
        var url = 'projects/' + id + '/contracts/' + name + '/methods';
        s.used = {
            privateKey: ''
        };
        s.idurl = "#/project/contract/"+id;
        s.modal1 = false;
        s.modal2 = false;
        s.functionList = [];
        s.default = '';
        s.sandBoxChecked = false;
        s.checkSandBox = function () {
            s.sandBoxChecked = !s.sandBoxChecked;
        };
        s.invokeMethods = function () {
            base.ajax(url, 'get', '', 2).success(function (data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].type == "function") {
                        s.functionList.push({
                            title: data[i].name,
                            val: data[i].name,
                            inputs: data[i].inputs,
                            outputs: data[i].outputs,
                            constant: data[i].constant,
                        });
                    }
                }
                s.selectFunction = s.functionList[0];
                s.inputsval = [];
                if (s.selectFunction != undefined) {
                    for (var i = 0; i < s.selectFunction.inputs.length; i++) {
                        s.inputsval.push('');
                    }
                }
            });
        }
        s.invokeMethods();

        s.selectFunction = [];
        s.selectchange = function (returns) {
            s.selectFunction = returns;
            s.inputsval = [];
            for (var i = 0; i < s.selectFunction.inputs.length; i++) {
                s.inputsval.push('');
            }
        }
        s.history = JSON.parse(localStorage.getItem('funHistory')) || [];
        s.list = [];
        s.index = 0;
        for (var i = 0; i < s.history.length; i++) {
            if (id == s.history[i].id && name == s.history[i].name) {
                s.list = s.history[i].list;
                s.index = i;
                break
            }
        }

        s.dofunction = function (needkey) {
            var startTime = new Date();
            if (needkey) {
                var key = s.used.privateKey;
            } else {
                var key = '';
            }
            var updata = {
                id: id,
                contractName: name,
                methodName: s.selectFunction.title,
                methodParams: [],
                //constant: s.selectFunction.constant,
                privateKey: key,
                password: s.paramData.password,
                constant: s.sandBoxChecked
            }
            var historyItem = {
                functionName: s.selectFunction.title,
                startTime: startTime,
                endTime: '',
                isError:false,
                info: { param: [], msg: [] }
            }

            var out_types = [];
            // var params = []

            for (var i = 0; i < s.selectFunction.inputs.length; i++) {
                var ok= util.solidityTypeCheck(s.selectFunction.inputs[i].type, s.inputsval[i]);
                if(ok){
                    toastr.error( $translate.instant('CONTRACT.paramtersValidateError.'+ok))
                    return
                }
                if(s.selectFunction.inputs[i].type=='bool'){
                    if(s.inputsval[i]=='true')
                        s.inputsval[i]=true
                    else
                        s.inputsval[i]=false
                }

                var patt = new RegExp(/int(\d*)\[(\d*)\]/g);
                var bytesArrayt = new RegExp(/bytes(\d*)\[(\d*)\]/g);
                var addrArrayt = new RegExp(/address(\d*)\[(\d*)\]/g);
                var isNumberArray = patt.test(s.selectFunction.inputs[i].type);
                var isBytesArray = bytesArrayt.test(s.selectFunction.inputs[i].type);
                var isAddrArray = addrArrayt.test(s.selectFunction.inputs[i].type);

                if (isNumberArray || isBytesArray || isAddrArray) {
                    if (s.inputsval[i].indexOf(",") != -1) {
                        var n_params = s.inputsval[i].split(",");
                        updata.methodParams.push(n_params);
                    } else {
                        var n_params_arr = [];
                        n_params_arr.push(s.inputsval[i]);
                        updata.methodParams.push(n_params_arr)
                    }
                } else {
                    updata.methodParams.push(s.inputsval[i])
                }

                // params[i] = s.inputsval[i];
                // if (s.selectFunction.inputs[i].type.startsWith("byte")) {
                //     var hex = util.ascii_to_hex(params[i] + "")
                //     console.warn(hex)
                //     params[i] = parseInt(hex,16);
                // }
                // updata.methodParams.push(params[i]);

                historyItem.info.param.push({
                    title: s.selectFunction.inputs[i].name == "" ? "args[" + i + "]" : s.selectFunction.inputs[i].name,
                    val: s.inputsval[i]
                });
            }

            for (var j = 0; j < s.selectFunction.outputs.length; j++) {
                out_types.push(s.selectFunction.outputs[j].type)
            }


            // var stringify = JSON.stringify(updata)
            // var content = JSON.parse(stringify);
            if (s.list.length == 0) {
                s.history.unshift({
                    id: id,
                    name: name,
                    list: [historyItem]
                })
                s.list = s.history[s.index].list;
            } else {
                s.history[s.index].list.unshift(historyItem);
            }

            var dataToShow = function(types,result){

                if (result instanceof Array) {
                    var i = 0   // i 表示返回参数的位置
                    for (; i < result.length;i++) {
                        if (result[i] instanceof Array) {
                            var j = 0;  // j 表示返回的参数是数组的话，j就是其索引
                            for (;j < result[i].length;j++) {
                                if (types[i].indexOf("byte") == 0) {
                                    result[i][j] = s.parseBytesData(result[i][j])
                                }
                            }
                        } else {
                            if (types.length == 1) {
                                if (types[0].indexOf("byte") == 0) {
                                    result[i] = s.parseBytesData(result[i])
                                } else if (i == result.length - 1){
                                        var new_arr = [];
                                        new_arr.push(result==null?"":result);
                                        return new_arr;
                                }
                            } else if (types[i].indexOf("byte") == 0) {
                                result[i] = s.parseBytesData(result[i]);
                            }

                        }
                    }
                } else {
                    var result_arr = [];
                    if (types.length > 0 && types[0].indexOf("byte") == 0) {
                        result = s.parseBytesData(result);
                    }
                    result_arr.push(result);
                    return result_arr
                }
                return result
            }

            base.ajax('projects/contracts/functions', 'post', updata).success(function (data) {
                var newdata = dataToShow(out_types,data.result)
                var endTime = new Date();
                historyItem.endTime = endTime;
                historyItem.info.msg = newdata;
                localStorage.setItem('funHistory', JSON.stringify(s.history));
                toastr.success($translate.instant("Common.Success"));
            }).error(function (data) {
                console.log(data.msg)
                if(!data.msg&&data.msg=="RangeError: private key length is invalid"){
                    s.used.privateKey=""
                    localStorage.removeItem("pK")
                }

                var endTime = new Date();
                historyItem.endTime = endTime;
                if (data.msg == "abi: cannot marshal in to go type: length insufficient 1 require 32") {

                }
                historyItem.info.msg = [data.msg];
                historyItem.isError = true;
                localStorage.setItem('funHistory', JSON.stringify(s.history));
            });
        }

        s.submit = function () {
            // if (!s.selectFunction.constant) {
            s.modal1 = true;
            // } else {
            //     s.dofunction(false);
            // }
        }

        /*上传私钥,the localstorage will save one copy*/
        s.pk=localStorage.getItem("pK")
        s.pkFileName=localStorage.getItem("pkFileName")
        s.used.privateKey=s.pk
        s.privKeyfile = function(file){
            s.file = $(file)[0].files[0];
//            var suffix = s.file.name.split('.').pop();
//
//            if (suffix == 'txt') {
                $(file).siblings().html(s.file.name)
                s.pkFileName=s.file.name
                var reader = new FileReader();
                reader.onload = function () {
                    len = this.result.length;
                    if (this.result.slice(len-1, len).charCodeAt() < 32){
                        s.used.privateKey = this.result.slice(0,len-1);
                    }else{
                        s.used.privateKey = this.result
                    }
                    localStorage.setItem("pK",s.used.privateKey )
                    localStorage.setItem("pkFileName",s.file.name )
                    s.pk=s.used.privateKey
                    s.$apply();
                }
                reader.readAsText(s.file);
//            } else {
//                text=$translate.instant("Chain.config.ImportPrivKey")
//                toastr.warning(text);
//            }
        }
        s.parseBytesData = function (data) {
            data = data==null?"":decodeURIComponent(escape(window.atob(data)));
            return data.replace(/\0/g, '');
        }

        s.paramData = {
            encrypted : false,
            password: ""
        }

        s.confirm = function () {
            if(!s.used.privateKey||s.used.privateKey.replace(/(^\s*)|(\s*$)/g,'')==''){
                toastr.error($translate.instant("Chain.config.ImportPrivKey"))
                return
            }

            if(s.paramData.encrypted && s.paramData.password == ""){
                toastr.warning("密码不能为空！")
                return
            }
            if(!s.paramData.encrypted){
                s.paramData.password = ""
            }

            s.modal1 = false;
            s.dofunction(true);
        }
        s.detail = function (info) {

            s.details = info.msg;
            s.param = info.param;
            s.modal2 = !s.modal2;
        }
    }
    ]);
});