define([
    'angular',
    'ace',
    'SweetAlert'
], function () {
    var module = angular.module('controllers');
    module.controller('contractDetailController', ['$scope', '$window', function ($scope, $window) {
        var s = $scope;
        var contract_detail = JSON.parse(localStorage.getItem('contracts_details'));
        s.returnUrl = "#/project/contract/" + contract_detail.id;
        s.toEdit = function (el) {
            editorDetail = $window.ace.edit(el);
            editorDetail.getSession().setMode("ace/mode/solidity");
            detail = contract_detail.name;
            editorDetail.setReadOnly(true);
            if (el.id == "abi") {
                editorDetail.setValue(contract_detail.abi);
            } else if (el.id == "code") {
                editorDetail.setValue(contract_detail.code == "" ? "No code!" : contract_detail.code);
            } else {
                editorDetail.setValue(contract_detail.source == "" ? "No source!" : contract_detail.source);
            }
        };

        s.name = contract_detail.name;
    }
    ]);
});