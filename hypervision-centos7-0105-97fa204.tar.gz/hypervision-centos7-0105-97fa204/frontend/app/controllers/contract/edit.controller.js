define([
    'angular',
    'toastr'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('contractEditController', ['$scope', 'base', '$http', '$location', '$translate', function ($scope, base, $http, $location, $translate) {
        var s = $scope;
        s.default = '';
        s.limit = 1;
        s.compiled = false;
        s.abis = [];
        s.currentEndpoint = {
            rpc:"loading"
        };
        base.ajax('currentEndpoint', 'get', {}).success(function (data) {
            s.currentEndpoint.rpc = data.endpoint;
        }).error(function (state) {
            s.currentEndpoint.rpc = 'not set'
        })
        //获取项目列表
        base.ajax('projects/all', 'get', {}).success(function (data) {
            s.list = [];
            var data = data.projects;
            for (var i = 0; i < data.length; i++) {
                if (!data[i].deployed) {
                    s.list.push({
                        id: data[i]._id,
                        name: data[i].name,
                        title: data[i].name,
                        val: data[i].name,
                        source: data[i].source,
                        type: data[i].type,
                        abis: data[i].contracts,
                        rpc: data[i].rpc
                    });
                }
            }
            s.selectedItem = s.list[0];
            s.abis = abitostring(s.selectedItem.abis);
        });
        s.isloading = false;
        //编译source
        s.compile = function () {
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"));
                return
            }
            s.isloading = true;
            var data = { source: s.selectedItem.source, endpoint: s.currentEndpoint.rpc};
            base.ajax('projects/contracts/abi', 'put', data).success(function (data) {
                s.compiled = true;
                s.isloading = false;
                s.abis = abitostring(data);
                toastr.success($translate.instant("CONTRACT.add.Compile_Success"));
            }).error(function (data) {
                toastr.warning(data.msg);
                s.isloading = false;
                s.compiled = false;
            });
        }

        // project selectchanges
        s.selectchange = function (returns) {
            s.selectedItem = returns;
            if (s.selectedItem.type == 'load') {
                if (s.selectedItem.abis[0] && typeof (s.selectedItem.abis[0].abi[0]) != 'string') {
                    s.abis = abitostring(s.selectedItem.abis);
                } else {
                    s.abis = s.selectedItem.abis;
                }
            } else {
                s.abis = [];
            }
            console.log(s.abis)
            if (s.abis.length >= 1){
                s.limit = 1;
            } else {
                s.limit = 0;
            }
            s.compiled = false;

        }
        //显示更多
        s.showMore = function () {
            s.limit = s.abis.length;
        }

        s.save = function () {
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"));
                return
            }
            s.selectedItem.abis = s.abis;  //合约信息
            // console.log(s.selectedItem.contracts)
            var contracts = abitobj(s.selectedItem.abis);
            var data = {
                    _id: s.selectedItem.id,
                    rpcAddr: s.currentEndpoint.rpc,
                    name: s.selectedItem.name,
                    source: s.selectedItem.source,
                    contracts: contracts
            }
            base.ajax('projects', 'put', data).success(function (data) {
                // toastr.success('Edit Project success');
                toastr.success($translate.instant("CONTRACT.edit.Modified"));
                $location.url("/contract");
            }).error(function (data) {
                s.selectItem.abis = abitostring(contracts)
                toastr.warning($translate.instant("CONTRACT.add." + data.msg));
            });
        }


        //load类型合约删除
        s.removeAbi = function (id) {
            s.abis.splice(id, 1);
            s.limit -= 1;
        }
        s.loadsave = function () {
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"));
                return
            }
            s.selectedItem.abis = s.abis;  //合约信息
            var contracts = abitobj(s.selectedItem.abis);
            var data = {
                _id: s.selectedItem.id,
                name: s.selectedItem.name,
                contracts: contracts,
                rpcAddr: s.currentEndpoint.rpc
            }
            for (var i = 0; i < data.contracts.length; i++) {
                if (data.contracts[i].abi.length == 0) {
                    data.contracts.splice(i, 1);
                }
            }
            base.ajax('projects', 'put', data).success(function (data) {
                // toastr.success('Edit Project success');
                toastr.success($translate.instant("CONTRACT.edit.Modified"));
                $location.url("/contract");
            }).error(function (data) {
                s.selectItem.abis = abitostring(contracts)
                toastr.warning($translate.instant("CONTRACT.add." + data.msg));
            });
        }

        //  get abi from local files
        s.apifile = function () {
            s.file = $('#abifile')[0].files[0];
            var file_length = s.file.name.split('.').length;
            var suffix = s.file.name.split('.')[file_length - 1];
            if (suffix == 'abi') {
                var reader = new FileReader();
                s.filetxt = s.file.name;
                var item = {
                    name: s.file.name.split('.')[0],
                    abi: []
                };
                reader.onload = function () {
                    var data = JSON.parse(this.result);

                    for(var i = 0; i < s.abis.length ; i++){
                        if (item.name == s.abis[i].name){
                            console.log(item.name == s.abis[i].name);
                            toastr.remove();
                            toastr.warning($translate.instant("CONTRACT.add.Repeated_Abi_Name"));
                            return
                        }
                        if (item.abi == s.abis[i].abi){
                            toastr.remove();
                            toastr.warning($translate.instant("CONTRACT.add.Repeated_Abi"));
                            return
                        }
                    }
                    for (var i = 0; i < data.length; i++) {
                        item.abi.push(JSON.stringify(data[i]));
                    }
                    s.abis.push(item);
                    s.limit = s.abis.length;
                    s.$apply();
                }
                reader.readAsText(s.file);
                console.log(s.limit)
            } else {
                toastr.remove();
                toastr.warning($translate.instant("CONTRACT.add.Upload_Abi"));
            }
        }

        function abitostring(data) {
            var abis = data;
            for (var j = 0; j < data.length; j++) {
                for (var i = 0; i < data[j].abi.length; i++) {
                    abis[j].abi[i] = JSON.stringify(abis[j].abi[i]);
                }
            }
            return abis;
        }

        function abitobj(data) {
            var abis = data;
            for (var j = 0; j < data.length; j++) {
                for (var i = 0; i < data[j].abi.length; i++) {
                    console.log(abis[j].abi[i])
                    abis[j].abi[i] = JSON.parse(abis[j].abi[i]);
                }
            }
            return abis;
        }
    }
    ]);
});