define([
    'angular',
    'toastr',
    'ace'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.directive("sedit",function () {
        return {
            restrict: "EA",
            require: '?ngModel',
            link: function(scope, element){
                setTimeout("",30);
                scope.toEdit(element[0])
            }
        }
    });
    module.controller('contractAddController', ['$scope', '$http', 'base', '$location','$translate', '$window',function ($scope, $http, base, $location,$translate, $window) {

        var s = $scope;

        s.toEdit = function (el) {
            if(el.id=="editorCreate"){
                s.editorCreate=$window.ace.edit(el);
                // s.editorCreate.setTheme("ace/theme/monokai");
                s.editorCreate.getSession().setMode("ace/mode/solidity");
            }
            return true
        };

        s.list = [
            // { title: 'openAuction', val: 'openAuction' },
            // { title: 'remotePurchase', val: 'remotePurchase' },
            {title:'hello', val:'hello'},
            {title:'SimulateBank', val:'SimulateBank'},
            {title:'accumulator', val:'accumulator'}
        ];
        s.default = { title: 'SimulateBank', val: 'SimulateBank' };
        s.selected = '';            //Pattern default
        s.limit_load = 2;
        s.limit_create = 1;
        s.projectType = 'create';
        s.projectName = '';
        s.pj = { source: '' };
        s.projectContracts_load = [];
        s.projectContracts_create = [];

        s.currentEndpoint = {
            rpc:"loading"
        };
        base.ajax('currentEndpoint', 'get', {}).success(function (data) {
            s.currentEndpoint.rpc = data.endpoint;
        }).error(function (state) {
            s.currentEndpoint.rpc = 'not set'
        })
        var url = 'file/SimulateBank.sol';
        $http.get(url).success(function (data) {
            s.editorCreate.setValue(data);
            s.pj.source = data;
        });

        //项目名称list获取，项目名称不能相同
        s.pjNameList = [];
        base.ajax('projects/all', 'get', {}).success(function (data) {
            var data = data.projects;
            for (var i in data) {
                s.pjNameList.push(data[i].name);
            }
        });

        s.typesfun = function (oldtype, type) {
            s.projectType = type;
            s.limit = 2;

            // if (oldtype != type) {
            //     // s.projectContracts = [];
            //     s.pj = { source: '' };
            //     $('#abifile').val('');
            // }
            // if (type == 'load') {
            //     s.file = '';
            // }
        }

        // create .sol file getdata
        s.selectchange = function (returns) {
            s.selected = returns.title;
            var url = 'file/' + s.selected + '.sol';
            $http.get(url).success(function (data) {
                s.editorCreate.setValue(data);
                s.pj.source = data;
            });
        }

        //abi compile
        s.isloading = false;
        var compiledSource;
        s.compile = function () {
            // better to use swal and suggesting user transfer to the endpoint list to set one
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"))
                return
            }
            s.pj.source=s.editorCreate.getValue();
            if (!s.isloading) {
                s.isloading = true;
                if (!s.pj.source ) {
                    toastr.warning("合约内容为空！");
                    s.isloading = false
                } else {
                    var data = { source: s.pj.source};
                    base.ajax('projects/contracts/abi', 'put', data).success(function (data) {
                        s.isloading = false;
                        s.projectContracts_create = data;
                        for (var i = 0; i < s.projectContracts_create.length; i++) {
                            var abi = s.projectContracts_create[i].abi;
                            for (var j = 0; j < abi.length; j++) {
                                delete abi[j].methodID;
                            }
                            s.projectContracts_create[i].abi = JSON.stringify(abi);
                        }
                        s.limit_create = 1;
                        toastr.remove();
                        toastr.success($translate.instant("CONTRACT.add.Compile_Success"));
                        compiledSource = s.pj.source;

                    }).error(function (data) {
                        toastr.warning(data.msg);
                        s.isloading = false
                    });
                }
            }
        }
        // create save
        s.projectSave = function () {
            if(s.projectName.length > 10 ){
                toastr.warning($translate.instant("CONTRACT.add.Project_Name_Exceed_10"));
                return
            }
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"))
                return
            }
            var savedSource = s.editorCreate.getValue();
            if (compiledSource != savedSource) {
                toastr.warning("合约已修改,请重新编译！");
                return
            }
            if (!savedSource ) {
                toastr.warning("合约内容为空！");
                return
            }
            for (var i in s.pjNameList) {
                if (s.projectName == s.pjNameList[i]) {
                    toastr.warning($translate.instant("CONTRACT.add.Project_Exist"));
                    return
                }
            }
            if (s.projectType == 'create') {
                s.projectContracts = s.projectContracts_create
            } else {
                s.projectContracts = s.projectContracts_load
            }

            if (s.projectName != '') {
                for (var i = 0; i < s.projectContracts.length; i++) {
                    s.projectContracts[i].abi = JSON.parse(s.projectContracts[i].abi);
                }
                var data = {
                    name: s.projectName,
                    type: s.projectType,
                    source: savedSource,
                    contracts: s.projectContracts
                };
                base.ajax('projects', 'post', data).success(function (data) {
                    toastr.remove()
                    toastr.success($translate.instant("Common.Create_Success"));
                    s.projectContracts = [];
                    s.projectName = '';
                    $location.url("/project");
                }).error(function (data) {
                    for (var i = 0; i < s.projectContracts.length; i++) {
                        s.projectContracts[i].abi = JSON.stringify(s.projectContracts[i].abi);
                        //s.projectContracts[i].abi = s.projectContracts[i].abi;
                    }
                    toastr.warning(data.msg);
                });
            } else {
                toastr.warning($translate.instant("CONTRACT.add.Project_Name_Required"));
            }

        }

        //  get abi from local files
        s.apifile = function () {
            s.file = $('#abifile')[0].files[0];
            var file_length = s.file.name.split('.').length;
            var suffix = s.file.name.split('.')[file_length - 1];
            if (suffix == 'abi') {
                var reader = new FileReader();
                var item = { name: s.file.name.split('.')[0], abi: [] };
                reader.onload = function () {
                    item.abi = this.result;
                    if (item.abi == "") {
                        toastr.warning("ABI文件内容为空,请重新上传！");
                        return
                    }
                    for(var i = 0; i < s.projectContracts_load.length ; i++){
                        if (item.name == s.projectContracts_load[i].name){
                            toastr.remove();
                            toastr.warning($translate.instant("CONTRACT.add.Repeated_Abi_Name"));
                            return                            
                        }
                        if (item.abi == s.projectContracts_load[i].abi){
                            toastr.remove();
                            toastr.warning($translate.instant("CONTRACT.add.Repeated_Abi"));
                            return
                        }
                    }
                    s.projectContracts_load.push(item);
                    s.limit_load = s.projectContracts_load.length;
                    $('#abifile').val('');
                    s.$apply();
                }
                reader.readAsText(s.file);
            } else {
                toastr.warning($translate.instant("CONTRACT.add.Upload_Abi"));
            }
        }
        s.pjloadSave = function () {
            if (s.currentEndpoint.rpc == 'not set') {
                toastr.remove()
                toastr.warning($translate.instant("Chain.endpoint.Not_Set"));
                return
            }
            if(s.projectName.length > 10 ){
                toastr.warning($translate.instant("CONTRACT.add.Project_Name_Exceed_10"));
                return
            }
            for (var i in s.pjNameList) {
                if (s.projectName == s.pjNameList[i]) {
                    toastr.warning($translate.instant("CONTRACT.add.Project_Exist"));
                    return
                }
            }
            if (s.projectName == '') {
                toastr.error($translate.instant("CONTRACT.add.Project_Name_Required"));
            } else if (s.projectContracts_load.length == 0) {
                toastr.error($translate.instant("CONTRACT.add.Upload_Abi"));
            } else {
                for (var i = 0; i < s.projectContracts_load.length; i++) {
                    try {
                        s.projectContracts_load[i].abi = JSON.parse(s.projectContracts_load[i].abi);
                    } catch (error) {
                        toastr.warning("ABI文件内容不符合json格式 !");
                        return
                    }
                }
                var data = {
                    name: s.projectName,
                    type: s.projectType,
                    contracts: s.projectContracts_load
                };
                base.ajax('projects', 'post', data).success(function (data) {
                    toastr.success($translate.instant("CONTRACT.add.Create_Success"));
                    s.projectContracts_load = [];
                    s.projectName = '';
                    $location.url("/project");
                }).error(function (data) {
                    for (var i = 0; i < s.projectContracts_load.length; i++) {
                        s.projectContracts_load[i].abi = JSON.stringify(s.projectContracts_load[i].abi);
                        //s.projectContracts_load[i].abi = s.projectContracts_load[i].abi;
                    }
                    toastr.warning($translate.instant("CONTRACT.add." + data.msg));
                });
            }

        };
        s.delabi = function (id) {
            if (s.projectType == 'create'){
                s.projectContracts = s.projectContracts_create
            } else {
                s.projectContracts = s.projectContracts_load
            }
            s.projectContracts.splice(id, 1);
            s.limit_load = s.limit_load > 2 ? s.limit_load - 1: s.limit_load;//保证s.limit_load大于２
        }
        // showmore
        s.showMore = function () {
            if (s.projectType == 'create'){
                s.limit_create = s.projectContracts_create.length
            } else {
                s.limit_load = s.projectContracts_load.length
            }
        }


    }
    ]);
});