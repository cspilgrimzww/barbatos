define([
    'angular',
    'toastr'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('contractController', ['$scope', '$cookieStore', 'base', '$http', '$location', '$timeout', '$translate', 'util', '$routeParams',
        function (s, $cookieStore, base, $http, $location, $timeout, $translate, util, $routeParams) {
            s.total = 0;
            s.flag = true;
            s.waitmsg = false;
            s.modal1 = false;
            s.modal2 = false;
            s.updata = {
                pageSize: 15,
                index: 1,
                status: '',
                sorter: '',
                rpcAddr: '',
                id: $routeParams.id
            };
            s.type = '部署';
            s.getresult = function (updata) {
                s.result = [];
                base.ajax('projects', 'get', updata).success(function (result) {
                    s.total = result.count;
                    var project = result.projects[0];
                    var contracts = project.contracts;
                    s.type = project.type == "create" ? "部署" : "加载";
                    for (var j = 0; j < contracts.length; j++) {
                        var contract = contracts[j];
                        if (contract.address == "") {
                            contract.address = undefined
                        }
                        s.result.push({
                            check: false,
                            _id: project._id,
                            // deployed:$translate.instant("Common."+ state),
                            status: contract.status,
                            source: contract.source,
                            address: contract.address,
                            time: contract.time,
                            type: project.type,
                            c_name: contract.name,
                            code: contract.code,
                            abi: JSON.stringify(contract.abi)
                        });
                    }
                }).error(function (data, state) {
                    if (state == 404) {
                        s.result = [];
                        toastr.warning("该合约项目已被删除！");
                    }
                });
            }
            base.ajax('projects/all', 'get', {}).success(function (result) {
                var data = result.projects;
                rpcMap = {}
                for (var i = 0; i < data.length; i++) {
                    s.pjlist.push({title: data[i].name, val: data[i].name, id: data[i]._id});
                    rpcMap[data[i].rpc] = 1
                }
                for (i in rpcMap) {
                    s.slist.push({title: i, val: i})
                }
            });
            s.getresult(s.updata);

            s.goPage = function (page) {
                s.updata.index = page;
                s.getresult(s.updata);
            };

            s.sort1 = 'projName';
            s.sort2 = 'type';
            s.sort3 = 'deployed';
            s.sort4 = 'rpcaddr';
            s.sort = function (type) {
                if (type == 'name') {
                    if (s.sort1 == 'name') {
                        s.sort1 = '-name';
                        s.s1 = true;
                    } else {
                        s.sort1 = 'name';
                        s.s1 = false;
                    }
                    s.updata.sorter = s.sort1;
                }
                if (type == 'type') {
                    if (s.sort2 == 'type') {
                        s.sort2 = '-type';
                        s.s2 = true;
                    } else {
                        s.sort2 = 'type';
                        s.s2 = false;
                    }
                    s.updata.sorter = s.sort2;
                }
                if (type == 'deployed') {
                    if (s.sort3 == 'deployed') {
                        s.sort3 = '-deployed';
                        s.s3 = true;
                    } else {
                        s.sort3 = 'deployed';
                        s.s3 = false;
                    }
                    s.updata.sorter = s.sort3;
                }
                if (type == 'rpcaddr') {
                    if (s.sort4 == 'rpcaddr') {
                        s.sort4 = '-rpcaddr';
                        s.s4 = true;
                    } else {
                        s.sort4 = 'rpcaddr';
                        s.s4 = false
                    }
                    s.updata.sorter = s.sort4;
                }
                s.getresult(s.updata);
            }
            var locallang = localStorage.getItem('setlanguage');
            // filter by contract stauts
            if (locallang == "zh") {
                s.slist = [{title: "全部", val: ''}];
                s.pjlist = [{title: "全部", val: ''}];
                s.default1 = {title: '全部'};
                s.default2 = {title: '全部'}
            } else {
                s.slist = [{title: "All", val: ''}];
                s.pjlist = [{title: "All", val: ''}];
                s.default1 = {title: 'All'};
                s.default2 = {title: 'All'}
            }


            s.selectchange1 = function (returns) {
                s.updata.index = 1;
                s.updata.rpcAddr = returns.val;
                s.defaultTitle = {title: "全部"};
                s.getresult(s.updata);
            }
            // filter by project name
            s.selectchange2 = function (returns) {
                s.updata.index = 1;
                s.defaultTitle = null;
                var d1 = {
                    id: returns.id,
                    rpcAddr: s.updata.rpcAddr
                }
                if (returns.val == '') {
                    s.getresult(s.updata);
                } else {
                    s.getresult(d1);
                }
            }
            //top3 buttons
            // delete && edit
            s.editProject = function () {
                $location.url("/contractEdit");
            }

            // 加载智能合约
            s.loaddatafun = function (id, name) {
                s.modal1 = !s.modal1;
                s.loadData = {
                    id: id,
                    contractName: name,
                    address: '',
                }
            }
            s.confirmLoad = function () {
                var data = s.loadData;
                var ok = util.solidityTypeCheck('address', data.address);
                if (ok) {
                    toastr.error($translate.instant('CONTRACT.paramtersValidateError.' + ok))
                    return
                } else {

                    base.ajax('projects/contracts', 'put', data).success(function (data) {
                        s.getresult(s.updata);
                        toastr.success($translate.instant('Common.Success'));
                    })
                    s.modal1 = !s.modal1;
                }
            }

            // 查询合约方法参数
            s.createdatafun = function (id, name) {
                s.modal2 = !s.modal2;
                s.operation = "deploy";
                s.operationData = {
                    id: id,
                    // privateKey: '2411065a721b9dab5ba8f833aa317a2723bbe7e90e41000052f2d5799384b877',
                    contractName: name,
                    params: '',
                }

                var apiurl = 'projects/' + id + '/contracts/' + name + '/constructor';
                base.ajax(apiurl, 'get', {}, 2).success(function (data) {
                    s.paramlist = [];
                    if (data.Inputs != null) {
                        for (var i = 0; i < data.Inputs.length; i++) {
                            s.paramlist.push({
                                name: data.Inputs[i].Name,
                                type: data.Inputs[i].Type,
                                val: '',
                            });
                        }
                    }
                })
            }

            s.update = function (id, name, type) {
                $location.url("/chaincode/project/contractUpdate/" + id + "/" + name + "/" + type);
            };
            /*上传私钥,the localstorage will save one copy*/
            s.pk = localStorage.getItem("pK")
            s.pkFileName = localStorage.getItem("pkFileName")
            s.privKeyfile = function (file) {
                s.file = $(file)[0].files[0];
//                var suffix = s.file.name.split('.').pop();
//                if (suffix == 'txt') {
                $(file).siblings().html(s.file.name)
                s.pkFileName = s.file.name
                var reader = new FileReader();
                reader.onload = function () {
                    len = this.result.length;
                    if (this.result.slice(len-1, len).charCodeAt() < 32){
                        s.operationData.privateKey = this.result.slice(0,len-1);
                    }else{
                        s.operationData.privateKey = this.result
                    }
//                    s.operationData.privateKey = this.result.slice(0, this.result.length - 1);
                    localStorage.setItem("pK", s.operationData.privateKey)
                    localStorage.setItem("pkFileName", s.file.name)
                    s.$apply();
                }
                reader.readAsText(s.file);
//                } else {
//                    toastr.warning('请选择txt文档.');
//                }
            }

            //确认部署
            confirmCreate = function () {
                s.operationData.privateKey = localStorage.getItem("pK")
                console.log(s.operationData.privateKey)
                if (!s.operationData.privateKey || s.operationData.privateKey.replace(/(^\s*)|(\s*$)/g, '') == '') {
                    toastr.error($translate.instant("Chain.config.ImportPrivKey"))
                    return
                }

                s.msgstatus = '';
                s.operationData.params = [];
                s.operationData.endpoint = s.endpoint;
                var data = s.operationData;
                data.password = s.paramData.password;
                for (var i = 0; i < s.paramlist.length; i++) {
                    var ok = util.solidityTypeCheck(s.paramlist[i].type, s.paramlist[i].val);
                    if (ok) {
                        toastr.error($translate.instant('CONTRACT.paramtersValidateError.' + ok))
                        return
                    }
                    if (s.paramlist[i].type == 'bool') {
                        if (s.paramlist[i].val == 'true')
                            s.paramlist[i].val = true
                        else
                            s.paramlist[i].val = false
                    }

                    var patt = new RegExp(/int(\d*)\[(\d*)\]/g)
                    var bytesArrayt = new RegExp(/bytes(\d*)\[(\d*)\]/g);
                    var addrArrayt = new RegExp(/address(\d*)\[(\d*)\]/g);
                    var isNumberArray = patt.test(s.paramlist[i].type);
                    var isBytesArray = bytesArrayt.test(s.paramlist[i].type);
                    var isAddrArray = addrArrayt.test(s.paramlist[i].type);
                    if (isNumberArray || isBytesArray || isAddrArray) {
                        if (s.paramlist[i].val.indexOf(",") != -1) {
                            var n_params = s.paramlist[i].val.split(",")
                            data.params.push(n_params)
                        } else {
                            var n_params_arr = []
                            n_params_arr.push(s.paramlist[i].val)
                            data.params.push(n_params_arr)
                        }
                    } else {
                        data.params.push(s.paramlist[i].val)
                    }
                }

                s.modal2 = false;
                s.waitmsg = true;
                base.ajax('projects/contracts', 'post', data)
                    .success(function (data) {
                        swal({
                            title: "部署合约",
                            type: "success",
                            showCancelButton: false,
                            showConfirmButton: true
                        });
//                        $timeout(function () {
                        s.waitmsg = false;
                        s.getresult(s.updata);
//                        }, 1500);
                    })
                    .error(function (data) {
                        swal({
                            title: "部署合约",
                            type: "error",
                            text: data.msg,
                            showCancelButton: false,
                            showConfirmButton: true
                        });
//                        s.msgstatus = data.msg;
//                        $timeout(function () {
                        s.waitmsg = false;
                        s.getresult(s.updata);
//                        }, 1500);
                    });
            }

            s.paramData = {
                encrypted: false,
                password: ""
            }
            s.confirm = function () {
                if (s.operation == "deploy") {
                    if (s.paramData.encrypted && s.paramData.password == "") {
                        toastr.warning("密码不能为空！")
                        return
                    }
                    if (!s.paramData.encrypted) {
                        s.paramData.password = ""
                    }
                    confirmCreate();
                } else if (s.operation == "lock" || s.operation == "unlock") {
                    confirmLockOrUnlock();
                }
            };
            s.clearFileInput = function (dom) {
                $(dom).val("");
                $(dom).click();
            }

            var skipMethodIDInABI = function (abi) {
                var abiObj = JSON.parse(abi);
                for (var i = 0; i < abiObj.length; i++) {
                    delete abiObj[i].methodID;
                }
                return JSON.stringify(abiObj)
            };

            // contract详细页面
            s.goDetail = function (id, name, source, code, abi) {
                localStorage.setItem('p_id', id);
                localStorage.setItem('c_name', name);
                abiNoMethodID = skipMethodIDInABI(abi);
                var contracts_details = {
                    id: id,
                    source: source,
                    abi: abiNoMethodID,
                    code: code,
                    name: name
                };
                localStorage.setItem('contracts_details', JSON.stringify(contracts_details));
                // localStorage.setItem('contracts_dname', name);
                $location.url("/project/contractDetail");
            }


            s.goGlance = function (id, address, name, abi) {
                localStorage.setItem('p_id', id);
                localStorage.setItem('c_name', name);
                var contracts_glance = {
                    id: id,
                    address: address,
                    name: name,
                    abi: abi

                };
                localStorage.setItem('contracts_glance', JSON.stringify(contracts_glance));
                // localStorage.setItem('contracts_dname', name);
                $location.url("/project/contractGlance");
            }

            //goInvoke visit invoke page
            s.goInvoke = function (id, name) {
                localStorage.setItem('p_id', id);
                localStorage.setItem('c_name', name);
                $location.url("/contractInvoke");
            }


            function unique5(array) {
                var r = [];
                for (var i = 0, l = array.length; i < l; i++) {
                    for (var j = i + 1; j < l; j++)
                        if (array[i].title === array[j].title && array[i].val === array[j].val) j = ++i;
                    r.push(array[i]);
                }
                return r;
            }

            s.lock = function (id, name) {
                s.modal2 = true;
                s.paramlist = [];
                s.operation = "lock";
                s.operationData = {
                    id: id,
                    contractName: name,
                    opcode: 2
                };
            };

            s.unlock = function (id, name) {
                s.modal2 = true;
                s.paramlist = [];
                s.operation = "unlock";
                s.operationData = {
                    id: id,
                    contractName: name,
                    opcode: 3
                };
            };

            confirmLockOrUnlock = function () {
                s.operationData.privateKey = localStorage.getItem("pK");
                base.ajax('projects/contracts/maintain', 'post', s.operationData).success(function (data) {
                    toastr.success($translate.instant('Common.Success'));
                    s.getresult(s.updata);
                }).error(function (data) {
                    toastr.error(data.msg);
                });
                s.modal2 = false;
            };


        }
    ]);
});
