define([
    'angular',
    'toastr'
], function (ng, toastr) {
    var module = angular.module('controllers');
    module.controller('projectController', ['$scope', '$cookieStore', 'base', '$http', '$location', '$timeout','$translate','util',
        function (s, $cookieStore, base, $http, $location, $timeout,$translate,util) {
            s.total = 0;
            s.flag = true;
            var endpoint = localStorage.getItem("endpoint");
            s.updata = {
                pageSize: 15,
                index: 1,
                status: '',
                sorter: '',
                endpoint: endpoint
            };
            s.defaultEndpoint = {title:endpoint, val : endpoint};
            s.endpointList = [{ title: 'All', val: 'All' }];
            s.getChainEndpointList = function () {
                base.ajax("chains/names","get", {}, 2)
                    .success(function (data) {
                        for (var i=0; i< data.length; i++) {
                            s.endpointList.push({title: data[i], val: data[i]})
                        }
                    })
                    .error(function () {
                        toastr.error($translate.instant("Chain.chainlist.Get_List_Failed"));
                    })
            };
            s.getChainEndpointList();

            s.getresult = function (updata) {
                s.result = [];
                base.ajax('projects', 'get', updata).success(function (result) {
                    s.total = result.count;
                    var data = result.projects;
                    if(data != null) {
                        for (var j = 0; j < data.length; j++) {
                            var project = data[j];
                            s.result.push({
                                check: false,
                                _id: project._id,
                                status: project.status,
                                type: $translate.instant("Common." + project.type),
                                name: project.name,
                                rpc: project.rpc,
                                namespace: project.namespace,
                                chainName: project.chainName
//                                chainName: project.endpoint.chainName
                            });
                        }
                    }

                    if (s.result.length == 0) {
                        s.flag = true;
                    } else {
                        s.flag = false;
                    }
                    s.selectalls = false;
                    s.idlist = [];
                });
            }
            s.getresult(s.updata);

            s.goPage = function (page) {
                s.updata.index = page;
                s.getresult(s.updata);
            }

            s.sort1 = 'projName';
            s.sort2 = 'type';
            s.sort3 = 'deployed';
            s.sort4 = 'endpoint';
            s.sort = function (type) {
                if (type == 'name') {
                    if (s.sort1 == 'name') {
                        s.sort1 = '-name';
                        s.s1 = true;
                    } else {
                        s.sort1 = 'name';
                        s.s1 = false;
                    }
                    s.updata.sorter = s.sort1;
                }
                if (type == 'type') {
                    if (s.sort2 == 'type') {
                        s.sort2 = '-type';
                        s.s2 = true;
                    } else {
                        s.sort2 = 'type';
                        s.s2 = false;
                    }
                    s.updata.sorter = s.sort2;
                }
                if (type == 'deployed') {
                    if (s.sort3 == 'deployed') {
                        s.sort3 = '-deployed';
                        s.s3 = true;
                    } else {
                        s.sort3 = 'deployed';
                        s.s3 = false;
                    }
                    s.updata.sorter = s.sort3;
                }
                if (type == 'endpoint'){
                    if(s.sort4 == 'endpoint'){
                        s.sort4 = '-endpoint';
                        s.s4 = true;
                    } else {
                        s.sort4 = 'endpoint';
                        s.s4 = false
                    }
                    s.updata.sorter = s.sort4;
                }
                s.getresult(s.updata);
            }
            var locallang = localStorage.getItem('setlanguage');
            // filter by contract stauts
            if(locallang=="zh"){
                s.slist = [{ title: "全部", val: '' }, { title: "待部署", val: 'undeployed' }, { title: "已部署", val: 'deployed' }];
                s.pjlist = [{ title: "全部", val: '' }];
                s.default = { title: '全部' }
            }else{
                s.slist = [{ title: "All", val: '' }, { title: "Pending", val: 'undeployed' }, { title: "Deployed", val: 'deployed' }];
                s.pjlist = [{ title: "All", val: '' }];
                s.default = { title: 'All' }
            }

            s.selectchange = function (returns) {
                s.updata.index = 1;
                if (returns.val == 'deployed') {
                    s.updata.status = 'deployed'
                } else if (returns.val == 'undeployed') {
                    s.updata.status = 'undeployed'
                } else {
                    s.updata.status = '';
                }
                s.getresult(s.updata);
            }
            // filter by project name
            s.selectchange2 = function (returns) {
                if (returns.val == 'All'){
                    s.updata.endpoint = ''
                }else {
                    s.updata.endpoint = returns.val;
                }
                s.updata.index = 1;
                s.getresult(s.updata);
            };
            //top3 buttons
            // delete && edit
            s.editProject = function (id) {
                $location.url("/chaincode/project/contractEdit/"+id);
            };


            // 首页列表全选
            s.selectalls = false;
            s.idlist = [];
            s.selectAll = function () {
                s.idlist = [];
                if (s.selectalls) {
                    for (var i = 0; i < s.result.length; i++) {
                        s.result[i].check = !s.selectalls;
                    }
                } else {
                    for (var i = 0; i < s.result.length; i++) {
                        s.result[i].check = !s.selectalls;
                        s.idlist.push(s.result[i]._id);
                    }
                }
                s.selectalls = !s.selectalls;
            }
            // select
            s.toogleSelect = function (i) {
                i.check = !i.check;
                if (!i.check) {
                    for (var j = 0; j < s.idlist.length; i++) {
                        if (s.idlist[j]._id == i._id) {
                            s.idlist.splice(j, 1);
                            break;
                        }
                    }
                } else {
                    s.idlist.push(i._id);
                }
                s.selectalls = true;
                for (var i = 0; i < s.result.length; i++) {
                    if (!s.result[i].check) {
                        s.selectalls = false;
                        break;
                    }
                }
            };

            s.deleteProject = function () {
                swal({
                        title: "你确定要删除吗?",
                        text: "你将会删除你选中合约!",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "删除",
                        cancelButtonText: "取消",
                        closeOnConfirm: false,
                        closeOnCancel: true
                    },
                    function (isConfirm) {
                        if (isConfirm) {
                            base.ajax('projects', 'DELETE', {ids: s.idlist})
                            .success(function (data) {
                                swal({
                                    title: "删除成功!",
                                    text: "合约项目删除成功!",
                                    type: "success",
                                    showConfirmButton: false,
                                    timer: 1000
                                });
                                s.getresult(s.updata);
                            })
                        } else {
                            swal("取消成功", ":)", "success");
                        }
                    }
                );
            }

            s.goContracts = function(id){
                $location.url('/project/contract/'+id);
            };

        }
    ]);
});
