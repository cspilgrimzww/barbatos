define([
    'echarts',
	'angular'
], function (echarts) {
	var module = angular.module('controllers');
	module.controller('bcsvController', ['$scope', 'base', '$interval', '$translate', '$location', function (s, base, $interval, $translate, $location) {
        s.interval_count = 0;
        s.interval_fail_count = 0; 
        s.data1 = 0;
        s.data2 = 0;
        s.data3 = 0;
        s.endpointlist = [];
        CONNECT_STATUS = {
        	DISCONNECTED: "disconnected",
			CONNECTED: "connected"
		}
        s.currentEndpoint = {
            rpc:"loading"
        };
        s.connect_status = "disconnected";
        base.ajax('currentEndpoint', 'get', {}).success(function (data) {
            s.currentEndpoint.rpc = data.endpoint;
            s.connect_status = "connected";
        }).error(function (state) {
            s.connect_status = "disconnected";
            s.currentEndpoint.rpc = 'not set'
        });
        if(s.connect_status == "connected"){
            base.ajax('stats', 'get', {}).success(function(data){
                console.log(data);
                s.interval_fail_count = data.intervalFailTransactionCount;
                s.interval_count = data.intervalTransactionSum;
                s.data1 = Math.round(data.successRate * 100);
                s.data2 = Math.round(data.changeRate * 100);
                s.data3 = Math.round(data.responseRate * 100);
            });
        };
		s.getData = function () {
            base.ajax('stats', 'get', {})
                .success(function (data) {
                    s.result = data;
                    if (s.result && (s.result.avgResponseTime > 99999 || s.result.avgResponseTime < -99999 )) {
                        s.result.avgResponseTime = "N/A"
                    }
                    s.timemax = Math.max.apply(null, s.result.blksIn40);
                    s.txCountListMax = Math.max.apply(null, s.result.txsIn40);
                    s.exeTimeListMax = Math.max.apply(null, s.result.exeTimeIn40);
                    s.interval_fail_count = data.intervalFailTransactionCount;
                    s.interval_count = data.intervalTransactionSum;
                    s.data1 = Math.round(data.successRate * 100);
                    s.data2 = Math.round(data.changeRate * 100);
                    s.data3 = Math.round(data.responseRate * 100);
                    s.changeSchart(s.data1);
                    s.changeCchart(s.data2);
                    s.changeRchart(s.data3);
                }).error(function () {
            })
        }
        s.changeSchart = function (sValue) {
            var showTip = $translate.instant("Chain.spvs.tran_suc_rate") + ": " + sValue + "%";
            if(sValue > 100){
                sValue = 100;
            }
            var option = {
                "animationDuration": [3000],
                "tooltip": {
                    "trigger": 'item',
                    "formatter": "{a}"
                },
                "series": [{
                    "name": showTip,
                    "center": [
                        "50%",
                        "50%"
                    ],
                    "radius": [
                        "50%",
                        "50%"
                    ],
                    "clockWise": false,
                    "hoverAnimation": false,
                    "type": "pie",
                    "data": [{
                        "value": sValue,
                        "name": "",
                        "label": {
                                "normal": {
                                    "show": true,
                                    "position": "center"
                                }
                            },
                            "labelLine": {
                                "show": false
                            },
                            "itemStyle": {
                                "normal": {
                                "color": "#5886f0",
                                "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(59,193,244,1)'
                                }, {
                                    offset: 1,
                                    color: 'rgba(59,193,244,0.5)'
                                }]),
                                "borderWidth": 5
                            }
                        },
                    }, {
                        "name": " ",
                        "value": 100-sValue,
                        "itemStyle": {
                            "normal": {
                                "label": {
                                "show": false
                                },
                                "labelLine": {
                                    "show": false
                                },
                                "color": '#f0efef',
                                "borderColor": '#f0efef',
                                "borderWidth": 5
                            }
                        }
                    }]
                }]
            };
            var sCharts = echarts.getInstanceByDom(document.getElementById("srate"));
            sCharts.setOption(option);
        }
        s.changeCchart = function (cValue) {
            var showTip = $translate.instant("Chain.spvs.tran_cha_rate") + ": " + cValue + "%";
            if(cValue > 100){
                cValue = 100;
            }
            var option = {
                "animationDuration": [3000],
                    "tooltip": {
                    "trigger": 'item',
                    "formatter": "{a}"
                },
                "series": [{
                    "name": showTip,
                    "center": [
                        "50%",
                        "50%"
                    ],
                    "radius": [
                        "50%",
                        "50%"
                    ],
                    "clockWise": false,
                    "hoverAnimation": false,
                    "type": "pie",
                    "data": [{
                        "value": cValue,
                        "name": "",
                        "label": {
                                "normal": {
                                    "show": true,
                                    "position": "center"
                                }
                            },
                            "labelLine": {
                                "show": false
                            },
                            "itemStyle": {
                                "normal": {
                                "color": "#5886f0",
                                "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(194,139,221,1)'
                                }, {
                                    offset: 1,
                                    color: 'rgba(194,139,221,0.5)'
                                }]),
                                "borderWidth": 5
                            }
                        },
                    }, {
                        "name": " ",
                        "value": 100-cValue,
                        "itemStyle": {
                            "normal": {
                                "label": {
                                "show": false
                                },
                                "labelLine": {
                                    "show": false
                                },
                                "color": '#f0efef',
                                "borderColor": '#f0efef',
                                "borderWidth": 5
                            }
                        }
                    }]
                }]
            };
            var sCharts = echarts.getInstanceByDom(document.getElementById("crate"));
            sCharts.setOption(option);
        }
        s.changeRchart = function (rValue) {
            var showTip = $translate.instant("Chain.spvs.tran_resp_rate") + ": " + rValue + "%";
            if(rValue > 100){
                rValue = 100;
            }
            var option = {
                "animationDuration": [3000],
                    "tooltip": {
                    "trigger": 'item',
                    "formatter": "{a}"
                },
                "series": [{
                    "name": showTip,
                    "center": [
                        "50%",
                        "50%"
                    ],
                    "radius": [
                        "50%",
                        "50%"
                    ],
                    "clockWise": false,
                    "hoverAnimation": false,
                    "type": "pie",
                    "data": [{
                        "value": rValue,
                        "name": "",
                        "label": {
                                "normal": {
                                    "show": true,
                                    "position": "center"
                                }
                            },
                            "labelLine": {
                                "show": false
                            },
                            "itemStyle": {
                                "normal": {
                                "color": "#5886f0",
                                "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgba(245,113,195,1)'
                                }, {
                                    offset: 1,
                                    color: 'rgba(245,113,195,0.5)'
                                }]),
                                "borderWidth": 5
                            }
                        },
                    }, {
                        "name": " ",
                        "value": 100-rValue,
                        "itemStyle": {
                            "normal": {
                                "label": {
                                "show": false
                                },
                                "labelLine": {
                                    "show": false
                                },
                                "color": '#f0efef',
                                "borderColor": '#f0efef',
                                "borderWidth": 5
                            }
                        }
                    }]
                }]
            };
            var sCharts = echarts.getInstanceByDom(document.getElementById("rrate"));
            sCharts.setOption(option);
        }
		//s.getData();
        bcsv_promise = JSON.parse(localStorage.getItem("bcsv_promise"));
        if (bcsv_promise){
        	$interval.cancel(bcsv_promise)
		}
        bcsv_promise = $interval(function () {
            if(s.connect_status == "connected"){
    			if ($location.$$url == '/blockchain/spvs') {
    				s.getData();
    			}
            }
		}, 500);
		localStorage.setItem("bcsv_promise", JSON.stringify(bcsv_promise));

		s.getNumber = function (num) {
			if (num != undefined && num > 0) {
				return new Array(num);
			} else {
				return [];
			}
		}
	}
	]);
});