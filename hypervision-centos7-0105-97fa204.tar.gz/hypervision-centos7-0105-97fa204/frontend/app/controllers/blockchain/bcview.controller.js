define([
    'angular',
    'jquery'
], function (ng, $) {
    var module = angular.module('controllers');
    module.controller('bcviewController', ['$scope', '$http', 'base', '$location', '$translate', function (s, $http, base, $location, $translate) {
        s.selectPage = 'block';
        s.total = 0;
        var explorerPath = 'explorer';
        s.data = {
            pageSize: 15,
            index: 1,
            search: ''
        }
        // 切换列表
        s.select = function (page) {
            s.selectPage = page;
            s.data.index = 1;
            s.data.search = '';
            localStorage.setItem('block_back', "");
            if (page == 'block') {
                s.getBlocks();
            } else if (page == 'transaction') {
                s.getTransactions();
            } else {
                s.getAccounts();
            }
        }

        CONNECT_STATUS = {
            DISCONNECTED: "disconnected",
            CONNECTED: "connected"
        }

        s.currentEndpoint = {
            rpc:"loading"
        };

        base.ajax('currentEndpoint', 'get', {}).success(function (data) {
            s.currentEndpoint.rpc = data.endpoint;
            s.connect_status = "connected";
        }).error(function (state) {
            s.connect_status = "disconnected";
            s.currentEndpoint.rpc = 'not set'
        });
        
        //获取区块列表
        s.getBlocks = function () {
            swal({
                title: $translate.instant("Common.Querying"),
                text:  $translate.instant("Common.Querying"),
                type: "info",
                showCancelButton: false,
                showConfirmButton: false
            })
            base.ajax(explorerPath + '/blocks', 'get', s.data).success(function (data) {
                s.result1 = data.list;
                s.total = data.count;
                swal.close()
            }).error(function () {
                swal.close()
            });
        }
        s.getBlocks();
        //获取交易列表
        s.getTransactions = function () {
            base.ajax(explorerPath + '/transactions', 'get', s.data).success(function (data) {
                s.result2 = data.list;
                s.total = data.count;
            });

        }

        //获取账户列表
        s.getAccounts = function () {
            base.ajax(explorerPath + '/accounts', 'get', s.data).success(function (data) {
                s.result3 = data;
                s.total = data.length;
            });
        }

        // 分页
        s.goPage = function (page) {
            s.data.index = page;
            if (s.selectPage == 'block') {
                s.getBlocks();
            } else if (s.selectPage == 'transaction') {
                s.getTransactions();
            } else {
                s.getAccounts();
            }
        }

        if (localStorage.getItem('block_back') == 'transaction') {
            s.select('transaction');
        } else if (localStorage.getItem('block_back') == 'account') {
            s.select('account');
        } else {
            s.select('block');
        }
        // 访问对应详情页
        s.goDetail = function (type, val) {
            var obj = {
                type: type,
                val: val
            }
            localStorage.setItem('bcview', JSON.stringify(obj));
            $location.url('/blockchain/viewdetail');
        }

        s.goDetail2 = function (type, address) {
            var obj = {
                type: type,
                address: address
            }
            localStorage.setItem('bcview', JSON.stringify(obj));
            $location.url('/blockchain/viewdetail');
        }

        s.search1 = function () {
            s.getBlocks();
        }
        s.search2 = function () {
            s.getTransactions();
        }
        s.search3 = function () {
            s.getAccounts();
        }
    }
    ]);
});