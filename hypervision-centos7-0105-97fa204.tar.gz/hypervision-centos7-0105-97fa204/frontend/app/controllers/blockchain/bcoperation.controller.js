define([
	'angular',
	'toastr',
	'SweetAlert'
], function (ng, toastr) {
	var module = angular.module('controllers');
	module.controller('bcoperationController', ['$scope', 'base', '$http', '$location', '$interval', '$translate','$window',function (s, base, $http, $location, $interval,$translate,$window) {
	    s.tip='';
	    s.total = 0;
		s.modal1 = false;
		s.modal2 = false;
		s.iplist = [];
		s.idlist = [];
		s.result = '';
		s.port = { start: '', end: '' };
		s.data = { host: [], namePrefix: '', cpu: 1, mem: 2, port: [] };
		// default
		s.default1 = { title: 'Api', val: 'api' };
		// s.cpulist = [{ title: '1', val: 1 }, { title: '4', val: 4 }, { title: '8', val: 8 }, { title: '16', val: 16 }, { title: '32', val: 32 }];
		s.cpulist = [{ title: 'auto', val: 1 }];
		s.default2 = { title: '1', val: 1 };
		// s.memlist = [{ title: '2', val: 2 }, { title: '4', val: 4 }, { title: '8', val: 8 }, { title: '16', val: 16 }];
		s.memlist = [{ title: 'auto', val: 2 }];
		s.default3 = { title: '2', val: 2 };
		isFirst = true;
		s.select_cpu = function (returns) { s.data.cpu = returns.val; }
		s.select_mem = function (returns) { s.data.mem = returns.val * 1024; }
		// 获取容器列表
		s.updata = { pageSize: 15, index: 1, search: '', type: '', sort: '' };
		s.blockchainId = localStorage.getItem("blockchainId");
		s.getlist = function (type) {
			if (isFirst == true){
                swal({
                    title: "正在查询",
                    text: "请等待...",
                    type: "info",
                    showCancelButton: false,
                    showConfirmButton: false
                });
				isFirst = false;
			}
			base.ajax('chains/' + s.blockchainId + "/nodes", 'get', s.updata).success(function (data) {
                swal.close()
				s.total = Math.ceil(data.count / s.updata.pageSize);

                 s.chain_status = data.chainStatus;
				if (s.result == '' || type == 'del' || type == 'add' || type == 'search' || type == 'page') {
					s.result = data.list;
					for (var i = 0; i < s.result.length; i++) {
						s.result[i].check = false;
					}

				} else {
					if(data.list.length == 0 && s.result.length != 0){
						s.updata.index = 1;
						s.getlist('del');
						s.result = []
						// toastr.success('容器删除成功');
					}
					for (var i = 0; i < data.list.length; i++) {
						s.result[i].status = data.list[i].status;
					}
				}
				if (data.list.length == 0) {
					s.selectalls = false;
				}
			});
		};

		s.getlist();
        bcendpoint_promise = JSON.parse(localStorage.getItem("bcendpoint_promise"));
        if (bcendpoint_promise){
            $interval.cancel(bcendpoint_promise)
        }
        bcendpoint_promise = $interval(function () {
            if ($location.$$url == '/blockchain/operation') {
                s.getlist();
            }
        }, 3000);
        localStorage.setItem("bcendpoint_promise", JSON.stringify(bcendpoint_promise));


		// 首页列表全选
		s.selectalls = false;
		s.selectAllx = function () {
			s.idlist = [];
			if (s.selectalls) {
				for (var i = 0; i < s.result.length; i++) {
					s.result[i].check = !s.selectalls;
				}
			} else {
				for (var i = 0; i < s.result.length; i++) {
					s.result[i].check = !s.selectalls;
					s.idlist.push(s.result[i]._id);
				}
			}
			s.selectalls = !s.selectalls;
		}
		// select
		s.toogleSelect = function (i) {
			i.check = !i.check;
			if (!i.check) {
				for (var j = 0; j < s.idlist.length; i++) {
					if (s.idlist[j].id == i._id) {
						s.idlist.splice(j, 1);
						break;
					}
				}
			} else {
				s.idlist.push(i._id);
			}
			s.selectalls = true;
			for (var i = 0; i < s.result.length; i++) {
				if (!s.result[i].check) {
					s.selectalls = false;
					break;
				}
			}
		}

		// 删除容器
		s.del = function () {
			if (s.chain_status == 'stop') {
				if (s.idlist.length == 0) {
					toastr.warning('请先选择容器');
				} else {
					swal("Waiting...", "please waiting...", "warning");

					base.ajax('chains', 'DELETE', { ids: s.idlist })
						.success(function (data) {
							s.updata.index = 1;
							swal({
								title: "容器删除成功！",
								// text: "",
								type: "success",
								customClass: 'swal-wide'
							});
							// s.getlist('del');
						})
						.error(function(){
							swal({
								title: "删除失败",
								// text: "",
								type: "error",
								customClass: 'swal-wide'
							});
						});
				}
			}
		}

		// 创建容器
		s.add = function () {
            var regx=/[\da-zA-Z]{1,32}/
            if(!regx.test(s.data.namePrefix)){
                toastr.error("名称前缀应该为1~32的字母和数字的组合！");
                return
            }
		    if (s.checkPortNum('start')!=''||s.checkPortNum('end')!=''){
		        return $translate.instant("Common.PortValidateTip")
            }
			s.data.port = [s.port.P2Pport];
			// s.data.port = [];
			s.data.host = [];
			// for (var i = s.port.start; i <= s.port.end; i++) {
			// 	s.data.port.push(i);
			// }
			for (var i = 0; i < s.iplist.length; i++) {
				s.data.host.push(s.iplist[i].ip);
			}

			if (s.data.host.length == 0) {
				toastr.warning('请选择服务器');
			} else if (s.data.namePrefix == '') {
				toastr.warning('请输入容器名称');
			} else {
				base.ajax('chains', 'post', s.data).success(function (data) {
					s.getlist('add');
				});
				toastr.success('正在添加容器');
				s.modal2 = false;
			}
		}

		s.tooglechain = function () {
			var opt = '';
			s.chain_status ? opt = 'stop' : opt = 'start';
			s.chain_status = !s.chain_status;
			base.ajax('chain/controller', 'post', { "opt": opt }).success(function (data) {
				s.getlist();
			});
		}


		// 排序
		s.s1 = s.s2 = s.s3 = s.s4 = false;
		s.sort = function (sort, x) {
			if (x == 1) { s.s1 = !s.s1; }
			else if (x == 2) { s.s2 = !s.s2; }
			else if (x == 3) { s.s3 = !s.s3; }
			else if (x == 4) { s.s4 = !s.s4; }
			if (sort == s.updata.sort) {
				s.updata.sort = "-" + sort;
			} else {
				s.updata.sort = sort;
			}
			s.getlist('search');
		}
		// 查看日志
		s.checklog = function (id) {
			s.modal1 = true;
			s.log = '';
			var url = "chains/" + s.blockchainId + "/nodes/" + id + "/logs";
			base.ajax(url, 'get', '', 2).success(function (data) {
				data.log == '' ? s.log = 'empty log' : s.log = data.log;
			});
		}
		// 分页跳转
		s.goPage = function (page) {
			s.updata.index = page;
			s.getlist('page');
		}
		// 启动/停止/重启容器
		s.sendCmd = function (id, type) {
			s.updata.sort = "";
			base.ajax('chains/' + s.blockchainId + '/nodes', 'put', { containerId: id, opt: type }).success(function (data) {
				s.getlist("search");
				// toastr.success('Operating, please wait..');
                toastr.remove();
				toastr.success('请求成功');
			});
		}
		// 搜索
		s.search = function () {
			s.updata.index = 1;
			s.getlist('search');
		}

		// host列表全选
		s.selectip = false;
		s.selectAll = function () {
			s.iplist = [];
			if (s.selectip) {
				for (var i = 0; i < s.serverlist.length; i++) {
					s.serverlist[i].check = !s.selectip;
				}
			} else {
				for (var i = 0; i < s.serverlist.length; i++) {
					s.serverlist[i].check = !s.selectip;
					s.iplist.push({ id: s.serverlist[i]._id, ip: s.serverlist[i].ip });
				}
			}
			s.selectip = !s.selectip;
		}

		// iplist
		s.selectItem = function (i) {
			i.check = !i.check;
			if (!i.check) {
				for (var j = 0; j < s.iplist.length; j++) {
					if (s.iplist[j].id == i._id) {
						s.iplist.splice(j, 1);
						break;
					}
				}
			} else {
				s.iplist.push({ id: i._id, ip: i.ip });
			}
			s.selectip = true;
			for (var j = 0; j < s.serverlist.length; j++) {
				if (!s.serverlist[j].check) {
					s.selectip = false;
					break;
				}
			}

		}
		s.checkPortNum=function(){
            // portStart = parseInt(s.port.start);
            // portEnd=parseInt(s.port.end)
			P2Pport = parseInt(s.port.P2Pport);
            $translate.instant("Common.PortValidateTip")
			// if (s.portRange(portEnd)&&s.portRange(portStart)){
			if (s.portRange(P2Pport)&&s.portRange(P2Pport+100)){
                return ""
            }else{
				console.log($translate.instant("Common.PortValidateTip"))
                return  $translate.instant("Common.PortValidateTip")
            }
		}
		s.portRange=function(port){
            if (isNaN(port) ||port<1025||port>=65535){
                return false
            }else{
                return true
            }
        }
		s.addbtn = function () {
			if(!s.isConfigured){
				toastr.warning('请先保存配置');
				return;
			}
			if(s.serverlist.length <= 0){
				toastr.warning('无可用服务器');
				return;
			}
			if (s.chain_status=='stop') {
				console.log(123);
				s.modal2 = true;
				s.port.start = '';
				s.port.end = '';
				s.port.P2Pport = '';
				s.data.namePrefix = '';
				s.iplist = [];
				s.selectip = true;
				for (var i = 0; i < s.serverlist.length; i++) {
					s.serverlist[i].check = true;
					s.iplist.push({ id: s.serverlist[i]._id, ip: s.serverlist[i].ip });
				}
			} else {
				toastr.warning('请先清空容器')
			}

		};
		s.clean = function () {
			// if (s.chain_status == 'stop'){
			// 	toastr.warning('Please deploy your block chain');
			// 	return;
			// }
			swal({
					title: "你确定要删除吗?",
					text: " 所有智能合约及其容器都将被删除!",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "确定",
					cancelButtonText: "取消",
					closeOnConfirm: false,
					closeOnCancel: true
				},
				function (isConfirm) {
					if (isConfirm) {
						for (var i = 0; i < s.result.length; i++) {
							s.idlist.push(s.result[i]._id);
						}

						swal({
							title: "正在删除中...",
							text: "请等待...",
							type: "warning",
							showCancelButton: false,
							showConfirmButton: false
						});

						base.ajax('chains', 'DELETE', { ids: s.idlist })
							.success(function (data) {
								// s.getlist();
								s.updata.index = 1;
								// $window.location.reload();
								swal({
									title: "容器删除成功！",
									// text: "",
									type: "success",
									customClass: 'swal-wide',
									confirmButtonColor: "#69b1d2"
								});
							})
							.error(function(err){
								s.updata.index = 1;
								// $window.location.reload();
								s.getlist('page');
								swal({
									title: "删除失败",
									// text: JSON.stringify(err),
									type: "error",
									customClass: 'swal-wide',
									confirmButtonColor: "#69b1d2"
								});
							});

						// base.ajax('chain/container', 'DELETE', { ids: s.idlist })
						// 	.success(function (data) {
						// 		s.updata.index = 1;
						// 		s.getlist('del');
						// 		swal("请求成功，正在删除！", "", "success");
						// 	});
					}
				}
			);
		};
		s.autoDeploy = function () {
			// if(s.chain_status != 'stop'){
			// 	toastr.warning('Please Clean your block chain');
			// } else {
				base.ajax('chain/autoDeploy', 'POST')
					.success(function (data) {
						s.updata.index = 1;
						s.getlist('add');
						toastr.success('请求成功 容器添加中');
					});
			// }
		}

	}]);
});