/**
 * Created by oem on 16-12-28.
 */

define([
    'angular',
    'toastr',
    'SweetAlert'
], function (ng,toastr) {
    var module = angular.module('controllers');
    module.controller('bcendpointController', ['$scope', 'base', '$http', '$location', '$interval', '$translate','$window',function (s, base, $http, $location, $interval,$translate,$window) {
        s.endpoint = {
            ip: "127.0.0.1",
            port: "8081",
            hostname: ""
        };
        s.result =[];
        s.idlist = [];
        s.selectalls = false;
        s.updata = { pageSize: 10, index: 1, search: '', type: '', sorter: '-timestamp', chainId: localStorage.getItem('endpoint_id') };
        s.total = 0;
        s.reloadWindow = function () {
            $window.location.reload();
        }
        s.getlist = function () {
            base.ajax("endpoints","get", s.updata)
                .success(function (data, state) {
                    s.total = Math.ceil(data.count / s.updata.pageSize);
                    s.result = data.list;
                    console.log(s.result);
                    s.selectalls = false
                    s.idlist = [];
                    s.selectalls = false;
                })
                .error(function (data) {
                    toastr.error($translate.instant("Chain.endpoint.Get_List_Failed"));
                })
        };
        s.setEndpoint = function(id){
            base.ajax("endpoints?action=set", "put", {id: id})
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                })
                .error(function(data){
                    toastr.warning($translate.instant("Chain.endpoint." + data.msg));
                })
        }
        s.getlist();
        s.goPage = function (page) {
            s.updata.index = page;
            s.getlist();
        }
        s.addbtn = function () {
            s.modal2 = true;
        };
        s.confirmCreate = function () {
            s.modal2 = false;
            swal({
                title: $translate.instant("Common.Waiting"),
                // text: $translate.instant("Common.Waiting"),
                type: "warning",
                showCancelButton: true,
                showConfirmButton: false
            });
            base.ajax("endpoints", "post",{ip: s.endpoint.ip, port:s.endpoint.port, chainId: localStorage.getItem('endpoint_id'), hostName: s.endpoint.hostname})
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                    s.getChangeRate()
                }).error(function (data, state) {
                console.log("Chain.endpoint." + data.msg);
                    swal({
                        title: $translate.instant("Common.Create_Failed"),
                        text: data.code == 1? $translate.instant("Chain.endpoint." + data.msg):$translate.instant("Chain.endpoint.Invalid_Endpoint"),
                        type: "error",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
            })
        }
        s.s1 = s.s2 = true;
        s.sort = function (sort, x) {
            if (x == 1) { s.s1 = !s.s1; }
            else if (x == 2) { s.s2 = !s.s2; }
            if (sort == s.updata.sorter) {
                s.updata.sorter = "-" + sort;
            } else {
                s.updata.sorter = sort;
            }
            s.getlist();
        }
        s.clean = function () {
            swal({
                    title: $translate.instant("Common.QueryConfirmDelete"),
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: $translate.instant("Common.Confirm"),
                    cancelButtonText: $translate.instant("Common.Cancel"),
                    closeOnConfirm: false,
                    closeOnCancel: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        swal({
                            title: $translate.instant("Common.Deleting"),
                            text: $translate.instant("Common.Waiting"),
                            type: "warning",
                            showCancelButton: false,
                            showConfirmButton: false
                        });

                        base.ajax('endpoints', 'DELETE', { ids: s.idlist })
                            .success(function (data) {
                                s.idlist = [];
                                s.getlist();
                                s.getChangeRate();
                                swal({
                                    title: $translate.instant("Common.Delete_Success"),
                                    type: "success",
                                    customClass: 'swal-wide',
                                    confirmButtonColor: "#69b1d2"
                                });
                            })
                            .error(function(err){
                                s.idlist = [];
                                // $window.location.reload();
                                s.getlist();
                                swal({
                                    title: $translate.instant("Common.QueryConfirmDelete"),
                                    text: JSON.stringify(err),
                                    type: "error",
                                    customClass: 'swal-wide',
                                    confirmButtonColor: "#69b1d2"
                                });
                            });

                    }
                }
            );
        };

        // 首页列表全选
        s.selectAllx = function () {
            s.idlist = [];
            if (s.selectalls) {
                for (var i = 0; i < s.result.length; i++) {
                    s.result[i].check = !s.selectalls;
                }
            } else {
                for (var i = 0; i < s.result.length; i++) {
                    s.result[i].check = !s.selectalls;
                    s.idlist.push(s.result[i]._id);
                }
            }
            s.selectalls = !s.selectalls;
        }
        // select
        s.toogleSelect = function (i) {
            i.check = !i.check;
            if (!i.check) {
                for (var j = 0; j < s.idlist.length; i++) {
                    if (s.idlist[j].id == i._id) {
                        s.idlist.splice(j, 1);
                        break;
                    }
                }
            } else {
                s.idlist.push(i._id);
            }
            s.selectalls = true;
            for (var i = 0; i < s.result.length; i++) {
                if (!s.result[i].check) {
                    s.selectalls = false;
                    break;
                }
            }
        }
        s.endpointStart = function (id) {
            base.ajax("endpoints?action=start", "put", {id: id})
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                })
        }

        s.endpointStop = function (id) {
            base.ajax("endpoints?action=stop", "put", {id: id})
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                })
        }
        s.changeRateStatus = false;
        s.disableChangeRate = false
        s.getChangeRate = function(){
            base.ajax('chains/changerate', 'get', {id:localStorage.getItem('endpoint_id')})
            .success(function(data){
                switch (data.code){
                    case 1000: s.changeRateStatus = true;
                               s.disableChangeRate = false;
                               break;
                    case 1001: s.changeRateStatus = false;
                               s.disableChangeRate = false;
                               break;
                    case 1002: s.disableChangeRate = true;
                               break;
                }
            })
        }
        s.getChangeRate();
		s.setChangeRate = function(id){
		    if (!s.result || s.result.length <= 0) {
		        toastr.warning($translate.instant("Chain.endpoint.NO_ENDPOINT_IN_CHAIN"))
		        return
		    }

		    base.ajax('chains/changerate', 'post', {id:localStorage.getItem('endpoint_id'),value: !s.changeRateStatus})
		    .success(function(data){
                    swal({
                        title: !s.changeRateStatus ? $translate.instant("Chain.endpoint.StartChangeRateSuccess"): $translate.instant("Chain.endpoint.StopChangeRateSuccess"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    s.changeRateStatus = !s.changeRateStatus
            });
		}

    }]);
});
