define([
    'angular'
], function () {
    var module = angular.module('controllers');
    module.controller('bcviewdetailController', ['$scope', '$route', 'base', '$location', function ($scope, $route, base, $location) {
        var s = $scope;
        // s.item = JSON.parse(localStorage.getItem('bcview'));

        s.total = 0;
        s.data = {
            pageSize: 15,
            index: 1,
            search: ''
        };

        s.explorerPath = 'explorer';

        var paging = function(txs, from, to){
            s.txs = txs.slice(from, to)
        };

        s.typecheck = function (isBlockHash) {
            s.item = JSON.parse(localStorage.getItem('bcview'));
            if (s.item.type == 'block') {
                s.blockD(isBlockHash);
            } else if (s.item.type == 'transaction') {
                s.transactionD();
            } else {
                s.accountD();
            }
        }
        s.blockD = function (isBlockHash) {
            if (s.explorerPath == ""){
                return
            }
            var data;
            if (isBlockHash) {
                data = {
                    hash: s.item.val
                };
            } else {
                data = {
                    blkNum: s.item.val
                };
            }

            base.ajax(s.explorerPath + "/blocks", 'get', data).success(function (data) {
                s.result = data;

                s.resultTxs = data.transactions;
                s.total = s.resultTxs.length;
                paging(s.resultTxs, 0 , s.data.pageSize);
            });
        }

        s.transactionD = function () {
            var data = {
                hash: s.item.val
            }
            base.ajax(s.explorerPath + '/transactions', 'get', data).success(function (data) {
                s.result = data;
            });
        }

        s.accountD = function () {
            var data = {
                address: s.item.address
            }
            // chain/explorer/transactions
            base.ajax(s.explorerPath + '/accounts', 'get', data).success(function (data) {
                s.baseinfo = data;
                s.result = data.txs;
            });
        }
        // 执行
        s.typecheck();

        s.back = function (blockback) {
            localStorage.setItem('block_back', blockback);
            $location.url("/blockchain/view");
        }

        // 详情页面
        s.goDetail = function (type, val) {
            var obj = {
                type: type,
                val: val
            }
            localStorage.setItem('bcview', JSON.stringify(obj));
            s.typecheck(true);
        }

        s.goBlockDetail = function(num) {
            var obj = {
                type: "block",
                val: num
            };
            localStorage.setItem('bcview', JSON.stringify(obj));
            s.typecheck(false);
        }

        s.goDetail2 = function (type, address) {
            var obj = {
                type: type,
                address: address
            }
            localStorage.setItem('bcview', JSON.stringify(obj));
            $location.url('/blockchain/viewdetail');
        }


        // 分页
        s.goPage = function (page) {
            paging(s.resultTxs, (page-1) * s.data.pageSize, page * s.data.pageSize);
        }
    }
    ]);
});