define([
    'angular',
    'jquery',
    'toastr'
], function (ng, $, toastr) {
    var module = angular.module('controllers');
    module.controller('bcconfigController', ['$scope', 'base', '$http', '$document', function ($scope, base, $http, $document) {
        var s = $scope;
        s.warnmsg = false;
        s.readonly = true;
        s.limitLength = 3;
        s.downloadlist = [];
        s.saveFlag = true;
        s.more = function () {
            s.limitLength = s.data.alloc.length;
        }
        s.data = {
            k: '10',
            batchsize: '500',
            batch: '1',
            request: '3',
            validateTime: '1',
            viewchange: '4',
            nullrequest: '4',
            resendviewchange: '10',
            txRatePeak: '50',
            txFillRate: '0.2',
            contractRatePeak: '20',
            contractFillRate: '0.8',
            vcresendlimit: "10",
            license: ''
        };
        // get data
        s.changeDisable = function () {
            document.getElementById('k').style.backgroundColor="#e5e8e9";
            document.getElementById('request').style.backgroundColor="#e5e8e9";
            document.getElementById('validateTime').style.backgroundColor="#e5e8e9";
            document.getElementById('viewchange').style.backgroundColor="#e5e8e9";
            document.getElementById('nullrequest').style.backgroundColor="#e5e8e9";
            document.getElementById('resendviewchange').style.backgroundColor="#e5e8e9";
            document.getElementById('resendviewchange').style.backgroundColor="#e5e8e9";
            document.getElementById('VcResendLimit').style.backgroundColor="#e5e8e9";
            
            document.getElementById('batchsize').style.backgroundColor="";
            document.getElementById('batch').style.backgroundColor="";
            document.getElementById('txRatePeak').style.backgroundColor="";
            document.getElementById('contractRatePeak').style.backgroundColor="";
            document.getElementById('license').style.backgroundColor="";
            document.getElementById('txFillRate').style.backgroundColor="";
            document.getElementById('contractFillRate').style.backgroundColor="";
            // document.getElementById('').style.backgroundColor="";
        };
        s.cancelDisable = function () {
            var a = document.getElementsByTagName("input");
            for(i = 0; i < a.length; i++){
                a[i].style.backgroundColor="#e5e8e9";
            }
        };
        s.getdata = function () {
            base.ajax('chains/conf', 'get', {})
                .success(function (result) {
                    s.saveFlag = true;
                    s.data = result;
                    s.data.k = '10';
                    s.data.validateTime = '1';
                    s.data.viewchange = '4';
                    s.data.nullrequest = '4';
                    s.data.resendviewchange = '10';
                    s.data.request = '3';
                    s.data.vcresendlimit = '10';
                    console.log(s.data);
                    while(s.data.batch.indexOf("s")!=-1){
                        s.data.batch = s.data.batch.toString();
                        s.data.batch = s.data.batch.substring(0,s.data.batch.length-1);

                    }
                    while(s.data.txFillRate.indexOf("ms")!=-1){
                        s.data.txFillRate = s.data.txFillRate.substring(0,s.data.txFillRate.length-2);
                    }
                    while(s.data.contractFillRate.indexOf("ms")!=-1){
                        s.data.contractFillRate = s.data.contractFillRate.substring(0,s.data.contractFillRate.length-2);
                    }
                    s.readonly = true;
                    s.cancelDisable();
                }).error(function () {
                s.readonly = false;
                s.saveFlag = false;
                s.changeDisable();
            });
        }

        s.getdata();
        // save data
        s.saveData = function () {
            if (!(s.data.batchsize&&s.data.batch&&s.data.request&&s.data.validateTime
                &&s.data.viewchange&&s.data.nullrequest&&s.data.resendviewchange&&s.data.txRatePeak
                &&s.data.txFillRate&&s.data.contractRatePeak&&s.data.contractFillRate&&s.data.license
                &&s.data.vcresendlimit)) {
                toastr.remove();
                toastr.warning('请完善表单信息！');
            } else if(s.data.license.length!=48){
                toastr.remove();
                toastr.warning('证书格式有误！');
            } else if(s.data.contractFillRate.match(/^\+{0,1}\d+(\.\d{1,9})?$/)==null){
                toastr.remove();
                toastr.warning('参数单节点合约并发恢复间隔格式有误！');
            } else if(s.data.txFillRate.match(/^\+{0,1}\d+(\.\d{1,9})?$/)==null){
                toastr.remove();
                toastr.warning('参数单节点交易并发恢复间隔');
            }else {
                var data2 = {
                    k: '10',
                    batchsize: '500',
                    batch: '1',
                    request: '3',
                    validateTime: '1',
                    viewchange: '4',
                    nullrequest: '4',
                    resendviewchange: '10',
                    txRatePeak: '50',
                    txFillRate: '0.2',
                    contractRatePeak: '20',
                    contractFillRate: '0.8',
                    vcresendlimit: "10",
                    license: ''
                };

                if(s.data.batch.indexOf('s')==-1) {
                    data2.k = s.data.k;
                    data2.resendviewchange = s.data.resendviewchange;
                    data2.batchsize = s.data.batchsize;
                    data2.license = s.data.license;
                    data2.contractRatePeak = s.data.contractRatePeak;
                    data2.txRatePeak = s.data.txRatePeak;
                    data2.batch = s.data.batch + 's';
                    data2.request = s.data.request + 's';
                    data2.validateTime = s.data.validateTime + 's';
                    data2.viewchange = s.data.viewchange + 's';
                    data2.nullrequest = s.data.nullrequest + 's';
                    data2.txFillRate = s.data.txFillRate + 'ms';
                    data2.contractFillRate = s.data.contractFillRate + 'ms';
                    data2.vcresendlimit = s.data.vcresendlimit
                }

                console.log(data2);
                base.ajax('chains/conf', 'post', data2)
                    .success(function (data) {
                        toastr.remove();
                        toastr.success('保存成功!');
                        s.getdata();
                    }).error(function (data) {
                        s.getdata();
                });
            }
        }
        // 重置config
        s.format = function () {
            s.warnmsg = true;
        }
        s.cancel = function () {
            s.warnmsg = false;
        }
        s.continue = function () {
            s.warnmsg = false;
            $http({
                method: 'DELETE',
                url: base.api + 'chains/conf',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': base.uptoken
                }
            }).success(function (data) {
                s.data = {
                    k: '10',
                    batchsize: '500',
                    batch: '1',
                    request: '3',
                    validateTime: '1',
                    viewchange: '4',
                    nullrequest: '4',
                    resendviewchange: '10',
                    txRatePeak: '50',
                    txFillRate: '0.2',
                    contractRatePeak: '20',
                    contractFillRate: '0.8',
                    vcresendlimit: "10",
                    license: ''
                };
                console.log("s.data"+JSON.stringify(s.data))
                s.readonly = false;
                s.changeDisable();
                s.secondReadOnly = true;
                toastr.success('重置成功！');
                s.saveFlag = false;
            }).error(function(data,err){
                s.saveFlag = true;
                toastr.remove();
                toastr.warning("尚未有保存的配置信息，无法重置");
            });
        }

        function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel) {
            var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
            var CSV = '';
            CSV += ReportTitle + '\r\n';
            if (ShowLabel) {
                var row = "";
                for (var index in arrData[0]) {
                    row += index + ',';
                }
                row = row.slice(0, -1);
                CSV += row + '\r\n';
            }
            for (var i = 0; i < arrData.length; i++) {
                var row = "";
                for (var index in arrData[i]) {
                    row += '"' + arrData[i][index] + '",';
                }
                row.slice(0, row.length - 1);
                CSV += row + '\r\n';
            }
            if (CSV == '') {
                return;
            }
            var fileName = "Alloc_" + Date.parse(new Date());
            fileName += ReportTitle.replace(/ /g, "_");
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            var link = document.createElement("a");
            link.href = uri;
            link.style = "visibility:hidden";
            link.download = fileName + ".csv";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
    ]);
});