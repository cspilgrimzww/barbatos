/**
 * Created by oem on 16-12-28.
 */

define([
    'angular',
    'toastr',
    'SweetAlert'
], function (ng,toastr) {
    var module = angular.module('controllers');
    module.controller('bcchainlistController', ['$scope', 'base', '$http', '$location', '$interval', '$translate','$window',function (s, base, $http, $location, $interval,$translate,$window) {
        var initChain = {
            "name":"test",
            "totalVolumnInterval":1440,
            "totalVolumnUpperLimit": 60000, 
            "changeRateInterval":120,
            "changeRateUpperLimit":1000, 
            "throughputInterval": 120,
            "throughputUpperLimit": 200,
            "successRateInterval": 120,
            "successRateLowerLimit": 80,
            "avgResponseTimeInterval": 120,
            "avgResponseTimeUpperLimit": 5000,
            "responseRateInterval": 120,
            "responseRateLowerLimit": 80,
            "responseTimeLimit": 3000,
            "failNumberInterval": 120,
            "failNumberUpperLimit": 10,
            "fsSpaceInterval": 120,
            "fsSpaceUpperLimit": 80,
            "fsCountInterval": 120,
            "fsCountUpperLimit": 10000
        }

        s.result =[];
        s.idlist = [];
        s.selectalls = false;
        s.updata = { pageSize: 10, index: 1, search: '', type: '', sorter: '-timestamp' };
        s.total = 0;
        s.reloadWindow = function () {
            $window.location.reload();
        }
        s.endpointList = function(id){
            localStorage.setItem("endpoint_id", id);
        }
        s.showConfig = function(data){
            s.chainlist = JSON.parse(JSON.stringify(data));
            s.chainlist.changeRateUpperLimit = data.changeRateUpperLimit * 100;
            s.chainlist.successRateLowerLimit = data.successRateLowerLimit * 100;
            s.chainlist.responseRateLowerLimit = data.responseRateLowerLimit * 100;
            s.chainlist.fsSpaceUpperLimit = data.fsSpaceUpperLimit * 100;
            s.modal2 = true;
            s.modifyMode = true;
        }
        s.startspv = function(id){
            base.ajax("/chains/spv","post", {id: id, action: "start"})
                .success(function(data, state){
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist();
                })
                .error(function (data) {
                    toastr.error($translate.instant("Chain.chainlist.Start_SPV_Fail"));
                })
        }
        s.stopspv = function(id){
            base.ajax("/chains/spv","post", {id: id, action: "stop"})
                .success(function(data, state){
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist();
                })
                .error(function (data) {
                    toastr.error($translate.instant("Chain.chainlist.Stop_SPV_Fail"));
                })
        }
        s.getlist = function () {
            base.ajax("chains","get", s.updata)
                .success(function (data, state) {
                    s.total = Math.ceil(data.count / s.updata.pageSize);
                    s.result = data.list;
                    s.selectalls = false
                    s.idlist = [];
                    s.selectalls = false;
                })
                .error(function (data) {
                    toastr.error($translate.instant("Chain.chainlist.Get_List_Failed"));
                })
        };
        s.getlist();
        s.goPage = function (page) {
            s.updata.index = page;
            s.getlist();
        }
        s.addbtn = function () {
            s.chainlist = JSON.parse(JSON.stringify(initChain));
            s.modal2 = true;
            s.modifyMode = false;
        };

        s.changeChainArgumentsToFloat = function (postChain) {
            postChain['totalVolumnInterval'] = parseFloat(s.chainlist.totalVolumnInterval);
            postChain['totalVolumnUpperLimit'] = parseFloat(s.chainlist.totalVolumnUpperLimit);
            postChain['changeRateInterval'] = parseFloat(s.chainlist.changeRateInterval);
            postChain['changeRateUpperLimit'] = parseFloat(s.chainlist.changeRateUpperLimit) / 100;
            postChain['throughputInterval'] = parseFloat(s.chainlist.throughputInterval);
            postChain['throughputUpperLimit'] = parseFloat(s.chainlist.throughputUpperLimit);
            postChain['successRateInterval'] = parseFloat(s.chainlist.successRateInterval);
            postChain['successRateLowerLimit'] = parseFloat(s.chainlist.successRateLowerLimit) / 100;
            postChain['avgResponseTimeInterval'] = parseFloat(s.chainlist.avgResponseTimeInterval);
            postChain['avgResponseTimeUpperLimit'] = parseFloat(s.chainlist.avgResponseTimeUpperLimit);
            postChain['responseRateInterval'] = parseFloat(s.chainlist.responseRateInterval);
            postChain['responseRateLowerLimit'] = parseFloat(s.chainlist.responseRateLowerLimit) / 100;
            postChain['responseTimeLimit'] = parseFloat(s.chainlist.responseTimeLimit);
            postChain['failNumberInterval'] = parseFloat(s.chainlist.failNumberInterval);
            postChain['failNumberUpperLimit'] = parseFloat(s.chainlist.failNumberUpperLimit);
            postChain['fsSpaceUpperLimit'] = parseFloat(s.chainlist.fsSpaceUpperLimit) / 100;
            postChain['fsSpaceInterval'] = parseFloat(s.chainlist.fsSpaceInterval);
            postChain['fsCountInterval'] = parseFloat(s.chainlist.fsCountInterval);
            postChain['fsCountUpperLimit'] = parseFloat(s.chainlist.fsCountUpperLimit);
        }


        s.confirmCreate = function () {
            s.modal2 = false;
            swal({
                title: $translate.instant("Common.Waiting"),
                // text: $translate.instant("Common.Waiting"),
                type: "warning",
                showCancelButton: true,
                showConfirmButton: false
            });
            var postChain = {};
            postChain['name'] = s.chainlist.name;
            s.changeChainArgumentsToFloat(postChain)
            base.ajax("chains", "post",postChain)
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                }).error(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Create_Failed"),
                        text: data.code == 1? $translate.instant("Chain.endpoint." + data.msg):$translate.instant("Chain.endpoint.Invalid_Endpoint"),
                        type: "error",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
            });
        }

        s.confirmModify = function () {
            s.modal2 = false;
            swal({
                title: $translate.instant("Common.Waiting"),
                // text: $translate.instant("Common.Waiting"),
                type: "warning",
                showCancelButton: true,
                showConfirmButton: false
            });
            var postChain = s.chainlist;
            s.changeChainArgumentsToFloat(postChain)
            base.ajax("chains", "put",postChain)
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Modify_Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                }).error(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Modify_Failed"),
                        text: data.msg,
                        type: "error",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
            });
         }

        s.s1 = s.s2 = true;
        s.sort = function (sort, x) {
            if (x == 1) { s.s1 = !s.s1; }
            else if (x == 2) { s.s2 = !s.s2; }
            if (sort == s.updata.sorter) {
                s.updata.sorter = "-" + sort;
            } else {
                s.updata.sorter = sort;
            }
            s.getlist();
        }
        s.setChain = function(id, name){
            base.ajax('endpoints', 'put', {id: id})
                .success(function(data){
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist();
                    localStorage.setItem("endpoint", name);
                })
                .error(function(data){
                    toastr.warning($translate.instant("Chain.endpoint." + data.msg));
                })
        }
        s.clean = function () {
            swal({
                    title: $translate.instant("Common.QueryConfirmDelete"),
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: $translate.instant("Common.Confirm"),
                    cancelButtonText: $translate.instant("Common.Cancel"),
                    closeOnConfirm: false,
                    closeOnCancel: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        swal({
                            title: $translate.instant("Common.Deleting"),
                            text: $translate.instant("Common.Waiting"),
                            type: "warning",
                            showCancelButton: false,
                            showConfirmButton: false
                        });

                        base.ajax('chains', 'delete', { ids: s.idlist })
                            .success(function (data) {
                                s.idlist = [];
                                s.getlist();
                                swal({
                                    title: $translate.instant("Common.Delete_Success"),
                                    type: "success",
                                    customClass: 'swal-wide',
                                    confirmButtonColor: "#69b1d2"
                                });
                            })
                            .error(function(err){
                                s.idlist = [];
                                // $window.location.reload();
                                s.getlist();
                                swal({
                                    title: $translate.instant("Common.QueryConfirmDelete"),
                                    text: JSON.stringify(err),
                                    type: "error",
                                    customClass: 'swal-wide',
                                    confirmButtonColor: "#69b1d2"
                                });
                            });

                    }
                }
            );
        };

        // 首页列表全选
        s.selectAllx = function () {
            s.idlist = [];
            if (s.selectalls) {
                for (var i = 0; i < s.result.length; i++) {
                    s.result[i].check = !s.selectalls;
                }
            } else {
                for (var i = 0; i < s.result.length; i++) {
                    s.result[i].check = !s.selectalls;
                    s.idlist.push(s.result[i]._id);
                }
            }
            s.selectalls = !s.selectalls;
        }
        // select
        s.toogleSelect = function (i) {
            i.check = !i.check;
            if (!i.check) {
                for (var j = 0; j < s.idlist.length; i++) {
                    if (s.idlist[j].id == i._id) {
                        s.idlist.splice(j, 1);
                        break;
                    }
                }
            } else {
                s.idlist.push(i._id);
            }
            s.selectalls = true;
            for (var i = 0; i < s.result.length; i++) {
                if (!s.result[i].check) {
                    s.selectalls = false;
                    break;
                }
            }
        }
        s.chainAlarmStart = function (id) {
            base.ajax("endpoints", "get", {pageSize: 10, index: 1, chainId: id})
                .success(function(data, state){
                    if(data.count != 0)
                        base.ajax("chains/alarm", "post", {id: id, action: "start"})
                            .success(function (data, state) {
                                swal({
                                    title: $translate.instant("Common.Success"),
                                    type: "success",
                                    showCancelButton: false,
                                    showConfirmButton: true
                                });
                                // setTimeout(s.reloadWindow,1000);
                                s.getlist()
                            });
                    else{
                        toastr.error($translate.instant("Chain.chainlist.No_Endpoint"));
                    }
                });
            
        }

        s.chainAlarmStop = function (id) {
            base.ajax("chains/alarm", "post", {id: id, action: "stop"})
                .success(function (data, state) {
                    swal({
                        title: $translate.instant("Common.Success"),
                        type: "success",
                        showCancelButton: false,
                        showConfirmButton: true
                    });
                    // setTimeout(s.reloadWindow,1000);
                    s.getlist()
                })
        }

    }]);
});
