define([
    'angular',
    'highchart'
], function () {

    angular.module('controllers').controller('summaryController', [
        '$scope', 'base', '$interval', '$location',
        function ($scope, base, $interval, $location) {
            var _self = $scope;
            var requestPath = 'summary';
            var lang = localStorage.getItem('setlanguage');
            if (lang != 'en') {
                _self.stauts = {
                    ready: "就绪",
                    running: "运行",
                    stopped: "停止",
                    unknown: "未知"
                }
                _self.server = {
                    deployed: "运行中",
                    live: "运行中",
                    died: "停机",
                    unknown: "故障"
                }

                _self.contract = {
                    self: "本机部署",
                    topThree: "前三部署总和",
                    others: "其他"
                }
            } else {
                _self.stauts = {
                    ready: "就绪",
                    running: "运行",
                    stopped: "停止",
                    unknown: "Unknown"
                }
                _self.server = {
                    deployed: "Online",
                    live: "Online",
                    died: "Offline",
                    unknown: "Disabled"
                }

                _self.contract = {
                    self: "Self deployed",
                    topThree: "Top three deployed",
                    others: "Others deployed"
                }
            }
            _self.currentEndpoint = {
                rpc: "loading"
            };
            _self.connect_status = "disconnected";
            base.ajax('currentEndpoint', 'get', {}).success(function (data) {
                _self.currentEndpoint.rpc = data.endpoint;
                _self.connect_status = "connected";
                localStorage.setItem('endpoint', data.endpoint);
                _self.getlist();
            }).error(function (state) {
                _self.connect_status = "disconnected";
                _self.currentEndpoint.rpc = 'not set';
                _self.getlist();
            })
            _self.totalServer = 0;
            _self.getlist = function () {
                if (_self.connect_status != "disconnected") {
                    base.ajax(requestPath, 'get', {}).success(function (data) {
                        _self.result = data;
                        if (_self.result && _self.result.alarmData && (_self.result.alarmData.avgResponseTime > 99999 || _self.result.alarmData.avgResponseTime < -99999)) {
                            _self.result.alarmData.avgResponseTime = "N/A"
                        }
                        _self.result.latestBlk = data.latestBlk == -1 ? 0 : data.latestBlk;
                        initPie(data.nodesInfo);
                        _self.totalServer = data.nodesInfo.all;
                        initStacked(data.txStatistics, 'day');
                        // initContainer(data.container);
                        initBarChart(data.smartCntr);
                        initContract(data.smartCntr);
                    });
                }
            }

            summary_promise = JSON.parse(localStorage.getItem("summary_promise"));
            if (summary_promise) {
                $interval.cancel(summary_promise)
            }
            summary_promise = $interval(function () {
                if (($location.$$url == '/' || $location.$$url == '/summary') && base.token) {
                    base.ajax(requestPath, 'get', {}).success(function (data) {
                        _self.result = data;
                        if (_self.result && _self.result.alarmData && (_self.result.alarmData.avgResponseTime > 99999 || _self.result.alarmData.avgResponseTime < -99999)) {
                            _self.result.alarmData.avgResponseTime = "N/A"
                        }
                    });
                }
            }, 3000);
            localStorage.setItem("summary_promise", JSON.stringify(summary_promise));

            $scope.initStacked = function (data, type) {
                initStacked(data, type);
            };
            $scope.tranSwitch = [true, false, false];

            function formatDate(time, type) {
                if (type == undefined) {
                    type = '-';
                }
                var year = time.getFullYear(time);
                var month = time.getMonth(time) + 1;
                var day = time.getDate(time);
                if (month < 10) {
                    month = '0' + month;
                }
                if (day < 10) {
                    day = '0' + day;
                }
                return year + type + month + type + day;
            }

            function changePointColor(data) {
                for (var i = 0 ; i < data.length; i++) {
                    if (data[i] > 0) {
                        data[i] = {"y": data[i], "color": "#11A0FF"}
                    }
                }
                return data;
            }

            function initStacked(data, type) {
                var chartData = {}, day = [], month = [], monthformat = [], week = [], weekformat = [];
                var d = new Date();
                var hour = d.getHours();
                var yes = new Date(d.setDate(d.getDate() - 1));
                for (var i = 0; i < 24; i++) {
                    var thisDay = (hour + i + 1) % 24;
                    if (hour + i - 24 >= 0) {
                        var thisDay = (hour + i - 23 + 1) % 24;
                    } else {
                        var thisDay = (hour + i + 1 + 1) % 24;
                    }
                    if (thisDay / 10 >= 1) {
                        thisDay = thisDay + ":00"
                    } else {
                        thisDay = "0" + thisDay + ":00"
                    }
                    day.push(thisDay);
                }
                for (var j = 0; j < 30; j++) {
                    var date = new Date();
                    var thisMonth = new Date(date.setDate(date.getDate() - 29 + j));
                    month.push(thisMonth.getDate());
                    monthformat.push(formatDate(thisMonth));
                }
                for (var k = 0; k < 7; k++) {
                    var date = new Date();
                    var thisweek = new Date(date.setDate(date.getDate() - 6 + k));
                    var getday = '';
                    switch (thisweek.getDay()) {
                        case 1:
                            getday = "Mon";
                            break;
                        case 2:
                            getday = "Tue";
                            break;
                        case 3:
                            getday = "Wed";
                            break;
                        case 4:
                            getday = "Thu";
                            break;
                        case 5:
                            getday = "Fri";
                            break;
                        case 6:
                            getday = "Sat";
                            break;
                        case 0:
                            getday = "Sun";
                            break;
                    }
                    week.push(getday);
                    weekformat.push(formatDate(thisweek));
                }
                switch (type) {
                    case 'day':
                        chartData.categories = day;
                        chartData.data = changePointColor(data.day);
                        // chartData.data = [1688,1788,1738,1798,1588,1388,1438,1598,1348,1240,1288,1420,1358,1490,1528,1628,1430,1418,1508,1528,1498,1458,1428,1418];
                        $scope.tranSwitch = [true, false, false];
                        break;
                    case 'month':
                        chartData.categories = month;
                        chartData.data = changePointColor(data.month);
                        $scope.tranSwitch = [false, false, true];
                        break;
                    case 'week':
                        chartData.categories = week;
                        chartData.data = changePointColor(data.week);
                        $scope.tranSwitch = [false, true, false];
                        break;

                }
                $('#stacked').highcharts({
                    chart: {
                        type: 'area',
                        plotBackgroundColor: '#fbfbfb',
                        plotBackgroundImage: 'assets/img/g1.png',
                    },
                    title: { text: '' },
                    xAxis: {
                        categories: chartData.categories,
                        tickmarkPlacement: 'on',
                        title: {
                            enabled: false
                        },
                        tickWidth: 0,
                    },
                    yAxis: {
                        title: { text: null },
                        labels: { y: 15 },
                        gridLineColor: '#e3e3e3',
                        allowDecimals: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(73,95,113,0.95)',
                        borderWidth: 0,
                        shadow: false,
                        borderRadius: 10,
                        style: {
                            color: '#fff',
                            fontWeight: 100
                        },
                        headerFormat: '',
                        useHTML: true,
                        pointFormatter: function () {
                            var format = '';
                            if (type == 'day') {
                                var mid = '';
                                var categoryHour =  this.category.split(":")[0]
                                if (categoryHour == 00 || hour + 1 < categoryHour) {
                                    format = formatDate(yes)
                                } else {
                                    format = formatDate(new Date())
                                }
                                var cate = parseInt(this.category, 10) - 1
                                if (cate >= 10) {
                                    cate = cate + ":00"
                                } else if (cate == -1) {
                                    cate = "23:00"
                                } else {
                                    cate = "0" + cate + ":00"
                                }
                                mid = cate + '-' + this.category  + '</br>';
                                return format + '</br>' + mid + this.y + ' transactions';
                            }
                            if (type == 'month') {
                                return monthformat[this.x] + '</br>' + this.y + ' transactions';
                            }
                            if (type == 'week') {
                                return weekformat[this.x] + '</br>' + this.y + ' transactions';
                            }
                        }
                    },
                    plotOptions: {
                        area: {
                            stacking: 'normal',
                            color: '#e6f4f8',
                            lineColor: '#65b9d5',
                            lineWidth: 1,
                            marker: {
                                lineWidth: 1,
                                lineColor: '#65b9d5',
                                // fillColor: '#fff'
                            },
                            showInLegend: false
                        }
                    },
                    series: [{
                        data: chartData.data
                    }]
                });
            }

            function initPie(data) {
                var statusTotal = data.all;
                if (statusTotal != 0) {
                    var seriesData = [{ name: _self.server.deployed, y: data.active, color: '#34e590' },
                    // {name: _self.server.died, y: data.stopped, color: '#ff6161'},
                    { name: _self.server.unknown, y: statusTotal - data.active, color: '#ffc261' }];
                } else {
                    var seriesData = [{ name: _self.server.deployed, y: 0, color: '#34e590' },
                    // {name: _self.server.died, y: 0, color: '#ff6161'},
                    { name: _self.server.unknown, y: 0, color: '#ffc261' },
                    { name: 'No Data', y: 1, color: '#f2f2f2' }];
                }
                $('#pie').highcharts({
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie',
                    },
                    title: {
                        text: null
                    },
                    tooltip: {
                        headerFormat: '',
                        //pointFormat: '{point.percentage:.1f}%',
                        backgroundColor: 'rgba(73,95,113,0.95)',
                        borderWidth: 0,
                        shadow: false,
                        borderRadius: 10,
                        style: { color: '#fff', fontWeight: 100 },
                        pointFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '<span>No Data</span>';
                            } else {
                                var format = '<span>' + Math.floor(this.percentage) + '%</span>';
                            }
                            return format;
                        },
                        useHTML: true
                    },
                    legend: {
                        symbolWidth: 0,
                        itemStyle: {
                            color: '#333',
                            fontWeight: '500',
                            fontSize: 12
                        },
                        labelFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '';
                            } else {
                                var format = '<span style="font-size:14px"> <i class="symbolHighchart" style="background:' + this.color + '"></i>' + this.name + '</span>';
                            }
                            return format;
                        },
                        useHTML: true
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: false
                            },
                            center: ['50%', '55%'],
                            borderWidth: 1,
                            borderColor: "#dcdcdc",
                            showInLegend: true,
                            size: '80%'
                        }
                    },
                    series: [{
                        colorByPoint: true,
                        data: seriesData
                    }]
                });
            };

            function initContainer(data) {
                var statusData = [{
                    name: _self.stauts.ready,
                    y: data.status.ready,
                    color: '#61d69e'
                }, {
                    name: _self.stauts.running,
                    y: data.status.running,
                    color: '#019FDA'
                }, {
                    name: _self.stauts.stopped,
                    y: data.status.stopped,
                    color: '#f69292'
                }
                    //     {
                    //     name: _self.stauts.unknown,
                    //     y: data.status.unknow,
                    //     color: '#bebcbc'
                    // }
                ];
                var total_status = data.status.ready + data.status.running + data.status.stopped + data.status.unknow;
                if (total_status == 0) {
                    statusData = [{
                        name: _self.stauts.ready,
                        y: data.status.ready,
                        color: '#61d69e'
                    }, {
                        name: _self.stauts.running,
                        y: data.status.running,
                        color: '#019FDA'
                    }, {
                        name: _self.stauts.stopped,
                        y: data.status.stopped,
                        color: '#f69292'
                    },
                    //     {
                    //     name: _self.stauts.unknown,
                    //     y: data.status.unknow,
                    //     color: '#bebcbc'
                    // },
                    {
                        name: 'No Data',
                        y: 1,
                        color: '#e8e8e8'
                    }];
                }
                // Create the chart
                $('#donut').highcharts({
                    chart: { type: 'pie' },
                    title: { text: null },
                    tooltip: {
                        //headerFormat: '{point.key}',
                        //pointFormat: '{point.y}',
                        shared: true,
                        backgroundColor: 'rgba(73,95,113,0.95)',
                        borderWidth: 0,
                        shadow: false,
                        borderRadius: 10,
                        style: { color: '#fff', fontWeight: 100 },
                        pointFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '';
                            } else {
                                var format = Math.floor(this.percentage) + '%';
                            }
                            return format;
                        },
                        useHTML: true
                    },
                    legend: {
                        align: 'right',
                        layout: 'vertical',
                        verticalAlign: 'middle',
                        symbolHeight: 10,
                        symbolWidth: 0,
                        symbolRadius: 5,
                        itemMarginTop: 10,
                        labelFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '';
                            } else {
                                // var format = this.name + " " + Math.floor(this.percentage) + '%';
                                var format = '<span style="font-size:14px"> <i class="symbolHighchart" style="background:' + this.color + '"></i>' + this.name + Math.floor(this.y) + '</span>';
                            }

                            return format;
                        },
                        useHTML: true,
                        itemStyle: {
                            fontWeight: 500,
                            color: '#333',
                            fontSize: 12,
                            letterSpacing: 0.5
                        }
                    },
                    plotOptions: {
                        pie: {
                            size: "88%",
                            innerSize: '66%',
                            shadow: false,
                            center: ['40%', '55%'],
                            showInLegend: true,
                            dataLabels: {
                                enabled: false
                            }
                        }
                    },
                    series: [{
                        data: statusData
                    }]
                });
            }

            function initBarChart(data) {
                var deArr = [], undeArr = [];
                undeArr.push(data.undeployed);
                deArr.push(data.deployed);
                var maxY = deArr[0] + undeArr[0];
                $('#barChart').highcharts({
                    chart: {
                        type: 'bar'
                    },
                    title: { text: null },
                    xAxis: {
                        categories: [''],
                        labels: {
                            enabled: false
                        },
                        lineWidth: 0,
                        tickWidth: 0,

                    },
                    yAxis: {
                        min: 0,
                        max: undeArr[0] + deArr[0],
                        title: { text: '' },
                        gridLineWidth: 0,
                        allowDecimals: false,
                        lineWidth: 1,
                        tickLength: 5,
                        tickWidth: 1,
                        tickPosition: "inside",
                    },
                    legend: {
                        reversed: true,
                        symbolHeight: 10,
                        symbolWidth: 10,
                        symbolRadius: 5,
                        itemStyle: {
                            color: '#333',
                            fontWeight: 'normal',
                            fontSize: '12px'
                        },
                        enabled: false
                    },
                    tooltip: {
                        headerFormat: '',
                        pointFormat: '{point.y} items',
                        useHTML: true,
                        backgroundColor: 'rgba(73,95,113,0.95)',
                        borderWidth: 0,
                        shadow: false,
                        borderRadius: 10,
                        style: { color: '#fff', fontWeight: 100 },
                    },
                    plotOptions: {
                        series: {
                            stacking: 'normal',
                            pointWidth: 30,
                            borderWidth: 0,
                        },
                    },
                    series: [{
                        name: 'Non-deployed',
                        data: undeArr,
                        color: '#d0d0d0',
                    }, {
                        name: 'Deployed',
                        data: deArr,
                        borderWidth: 0,
                        color: {
                            linearGradient: [0, 0, 0, 400],
                            stops: [[0, '#60ce90'], [1, '#00a9f0']]
                        },
                    }]
                });
            }

            function initContract(data) {
                var seriesData = [{ name: _self.contract.self, y: 5, color: '#34e590' },
                { name: _self.contract.topThree, y: 20, color: '#ff6161' },
                { name: _self.contract.others, y: 50, color: '#ffc261' }]

                $('#contract').highcharts({
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie',
                    },
                    title: {
                        text: null
                    },
                    tooltip: {
                        headerFormat: '',
                        //pointFormat: '{point.percentage:.1f}%',
                        backgroundColor: 'rgba(73,95,113,0.95)',
                        borderWidth: 0,
                        shadow: false,
                        borderRadius: 10,
                        style: { color: '#fff', fontWeight: 100 },
                        pointFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '<span>No Data</span>';
                            } else {
                                var format = '<span>' + Math.floor(this.percentage) + '%</span>';
                            }
                            return format;
                        },
                        useHTML: true
                    },
                    legend: {
                        symbolWidth: 0,
                        itemStyle: {
                            color: '#333',
                            fontWeight: '500',
                            fontSize: 12
                        },
                        labelFormatter: function () {
                            if (this.name == 'No Data') {
                                var format = '';
                            } else {
                                var format = '<span style="font-size:14px"> <i class="symbolHighchart" style="background:' + this.color + '"></i>' + this.name + '</span>';
                            }
                            return format;
                        },
                        useHTML: true
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: false
                            },
                            center: ['50%', '55%'],
                            borderWidth: 1,
                            borderColor: "#dcdcdc",
                            showInLegend: true,
                            size: '80%'
                        }
                    },
                    series: [{
                        colorByPoint: true,
                        data: seriesData
                    }]
                });
            }

        }
    ]);

});