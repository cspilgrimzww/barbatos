/**
 * Created by gobella on 16-11-17.
 */
define([
    'angular',
    'jquery',
    'toastr',
    'SweetAlert',
], function (ng, $, toastr){
    angular.module('controllers').controller('userController', [
        '$scope', 'util', 'base', '$http', '$interval', '$location', function ($scope, util, base, $http, $interval, $location) {
            $scope.newpassword=""
            $scope.ackpassword=""
            $scope.oldpassword=""
            // $scope.data.authToken=base.token

            $scope.modify=function () {
                var reg=/^[\da-zA-Z]{6,16}$/;
                console.log(reg)

                if (!reg.test($scope.newpassword)){
                    toastr.error("密码应该在6~16位的字母和数字的组合！")
                    return
                }
                if($scope.newpassword!=$scope.ackpassword){
                    toastr.error("兩次輸入不一致")
                    return
                }
                datetransfer={
                    newPwd:$scope.newpassword,
                    oldPwd:$scope.oldpassword
                }
                base.ajax('user/pwd', 'post', datetransfer)
                    .success(function (data) {
                        if(data.msg=='ok'){
                            base.ajax('logout', 'get', {}).success(function (datas) {
                                base.token = "";
                                $location.url('/user/login');
                                // $scope.token = "";
                                localStorage.setItem('token', "");
                                localStorage.clear();
                                toastr.success('修改成功,请重新登录!');
                            });
                        }else if (data.msg=="oldpwdwrong") {
                            toastr.error('原密码与当前密码不匹配!')
                        }else{
                            toastr.error("token过期或token不合法")
                        }

                    });
            }


        }
    ]);

});