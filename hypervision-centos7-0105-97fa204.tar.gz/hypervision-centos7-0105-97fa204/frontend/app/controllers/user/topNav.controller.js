/**
 * Created by gobella on 16-11-18.
 */
define([
    'angular',
    'jquery',
    'toastr',
], function (ng, $, toastr){
    var topNavController = function ($scope, util, base, $http, $interval, $location) {
        $scope.myFunction=function(){
            console.log("test")
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }

    };
    angular.module('controllers').controller('userController', [
        '$scope', 'util', 'base', '$http', '$interval', '$location', topNavController
    ]);

});