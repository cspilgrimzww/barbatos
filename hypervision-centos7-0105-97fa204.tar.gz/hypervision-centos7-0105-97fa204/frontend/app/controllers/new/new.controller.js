define([
	'angular'
], function () {
	var module = angular.module('controllers');
	module.controller('newController', ['$scope', function ($scope) {
		
	}
	]);
});