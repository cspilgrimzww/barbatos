define([
	'angular'
], function () {

	angular.module('controllers').controller('translateController', [
		'$scope', '$translate', '$location',
		function ($scope, $translate, $location) {

			$scope.changeLanguage = function (langKey) {
				$translate.use(langKey);
                $scope.lang = langKey;
				localStorage.setItem('setlanguage', langKey);
				window.location.reload();
			}
			var locallang = localStorage.getItem('setlanguage');
			if (locallang) {
				$scope.lang = locallang;
			} else {
				$scope.lang = 'zh';
			}
			$translate.use($scope.lang);
			$scope.lang = $scope.lang;
			localStorage.setItem('setlanguage', $scope.lang);
		}
	]);

});