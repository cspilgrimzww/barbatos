define([
	'angular',
], function () {

	angular.module('controllers').controller('topController', [
		'$scope',
		function ($scope) {
			$scope.menu = [false,false,false,false,false,false,false];
			$scope.active = function(index,name){
				$scope.name = name;
				var menu = [false,false,false,false,false,false,false];
				menu[index] = true;
				$scope.menu = menu;
			};
			$scope.showMenu = [false,false];
			$scope.show = function(index){
				var showMenu = [false,false];
				showMenu[index] = true;
				$scope.showMenu = showMenu;
			}
		}
	]);

});