define([
    'angular',
    'toastr'
], function (ng, toastr) {
    angular.module('app').controller("app", ['$scope', 'base', '$http', '$cookieStore', '$window',
    '$interval','$location', '$translate', function ($scope, base, $http, $cookieStore, $window,
      $interval,$location, $translate) {
        $scope.token = base.token;
        $scope.dropdown = false;
        $scope.showTopMenu=function($event){
            if (!$scope.dropdown) {
                $scope.dropdown=!$scope.dropdown
            }

            $(document).one("click", function (){//对document绑定一个影藏Div方法

                if ($scope.dropdown) {
                    $scope.dropdown=!$scope.dropdown
                }
            });

            event.stopPropagation();//阻止事件向上冒泡

        }

        $scope.stopEvent = function(event){
            event.stopPropagation();//阻止事件向上冒泡
        }
        $scope.hideTopMenu = function(){
            if ($scope.dropdown) {
                $scope.dropdown=!$scope.dropdown
            }
        }

        $interval(function () {
            if (base.token == '') {
                $scope.token = '';
            }
        }, 1000);
        $scope.name = 'MENU.SUMMARY';
        $scope.menu = '/summary';
        var refresh = true;
        $scope.thisyear = (new Date()).getFullYear();
        checkCookie();
        $scope.$on('$routeChangeStart', function (target, next) {
            var page_arr = [];
            page_arr = next.originalPath.split('/');
            if (page_arr[1]) {
                $scope.name = "MENU." + page_arr[1].toUpperCase();
            }
            if (!!page_arr[2]) {
                $scope.sec_name = "MENU." + page_arr[2].toUpperCase();
            } else {
                $scope.sec_name = "";
            }
            $scope.menu = next.originalPath;
            if (!refresh && !!$scope.showMenu) {
                $scope.showMenu = $scope.menu.indexOf('blockchain') > -1 ? 'show' : 'hide';
            } else {
                $scope.showMenu = $scope.menu.indexOf('blockchain') > -1 ? 'show' : '';
            }
            refresh = false;
        });

        $scope.show = function () {
            $scope.showMenu = $scope.showMenu == 'show' ? 'hide' : 'show';
            $scope.menu = '/blockchain/spvs';
        }
        $scope.canLog = false;
        if ($scope.password != '' && $scope.password != null) {
            $scope.canLog = true;
        }
        $scope.logKeyup = function (u, p) {
            $scope.canLog = u && p ? true : false;
        }

        $scope.login_status = false;
        $scope.login_title = '登 录';
        $scope.login = function (email, password) {
            if (!$scope.login_status && $scope.canLog) {
                $scope.login_title = "登录中..";
                $scope.login_status = true;
                localStorage.setItem('token', email);
                base.password = password;
                base.ajax('token', 'post', {}).success(function (data) {
                    $scope.login_title = "登 录";
                    $scope.login_status = false;
                    setCookie('usering', 1);
                    base.password = "";
                    localStorage.setItem('token', data.data);
                    localStorage.setItem('endpoint', "未设置");
                    localStorage.setItem("connect_status", 'disconnected');//endpoint connect status;
                    localStorage.setItem('u_ser', email);   //username
                    $scope.username = localStorage.getItem('u_ser');
                    $scope.token = data.data;
                    toastr.remove();
                    toastr.success('登陆成功');
                    $location.url('/summary');

                }).error(function (data) {
                    toastr.remove();
                    // toastr.error(data.msg || $translate.instant('Common.Auth_Failed'));
                    toastr.error("用户名或者密码错误!");
                    $scope.login_title = "登 录";
                    $scope.login_status = false;
                });
            }
        };
        $scope.logout = function (email, password) {
            // $location.url('/contract');
            base.ajax('logout', 'get', {}).success(function (data) {
                $scope.token = "";
                localStorage.setItem('token', "");
                toastr.success('登出成功');
                localStorage.clear();
                $location.url('/user/login');
            });
        }
        $scope.username = localStorage.getItem('u_ser');

        function getCookie(c_name) {
            if (document.cookie.length > 0) {
                c_start = document.cookie.indexOf(c_name + "=")
                if (c_start != -1) {
                    c_start = c_start + c_name.length + 1
                    c_end = document.cookie.indexOf(";", c_start)
                    if (c_end == -1) c_end = document.cookie.length
                    return unescape(document.cookie.substring(c_start, c_end))
                }
            }
            return ""
        }
        function setCookie(c_name, value, expiredays) {
            var exdate = new Date()
            exdate.setDate(exdate.getDate() + expiredays)
            document.cookie = c_name + "=" + escape(value) +
                ((expiredays == null) ? "" : "; expires=" + exdate.toGMTString())
        }
        function checkCookie() {
            username = getCookie('usering')
            if (username == null || username == "") {
                $scope.token = "";
                localStorage.setItem('token', "");
                localStorage.clear();
            }
        }

        // 记住密码
        if (getCookie('username') != '' && getCookie('username') != null) {
            $scope.checked = true;
            $scope.username = getCookie('username');
        } else {
            $scope.checked = false;
        }

        $scope.remember = function (username) {
            if (!$scope.checked) {
                setCookie('username', username, 30);
            } else {
                setCookie('username', '');
            }
            $scope.checked = !$scope.checked;
        }
    }]);
});