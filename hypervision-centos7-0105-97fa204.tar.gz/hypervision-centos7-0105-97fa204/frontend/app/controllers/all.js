define([
	'app/controllers/main.controller',
	'app/controllers/translate.controller',
	'app/controllers/summary/summary.controller',
	'app/controllers/server/server.controller',
    'app/controllers/server/sdetail.controller',
	'app/controllers/contract/contract.controller',
	'app/controllers/contract/add.controller',
	'app/controllers/contract/detail.controller',
	'app/controllers/contract/glance.controller',
	'app/controllers/contract/edit.controller',
	'app/controllers/contract/invoke.controller',
	'app/controllers/contract/del.controller',
	'app/controllers/contract/project.controller',
	'app/controllers/blockchain/bcsv.controller',
    'app/controllers/blockchain/bcconfig.controller',
    'app/controllers/blockchain/bcendpoint.controller',
    'app/controllers/blockchain/bcchainlist.controller',
	'app/controllers/blockchain/bcoperation.controller',
	'app/controllers/blockchain/bcmanager.controller',
	'app/controllers/blockchain/bcview.controller',
	'app/controllers/blockchain/bcviewdetail.controller',
	'app/controllers/new/new.controller',
	'app/controllers/user/user.controller'
], function () {

});