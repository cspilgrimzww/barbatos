define([
    'app/directives/contract_direct',
    'app/directives/bcsv_direct'
], function () {

});