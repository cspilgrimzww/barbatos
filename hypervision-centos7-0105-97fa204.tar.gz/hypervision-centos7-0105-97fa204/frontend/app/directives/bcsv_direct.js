define([
    'echarts',
    'angular'
], function (echarts) {
    var module = angular.module('directives');

    module.directive('rate1', function() {  
	    return {  
	        scope: {  
	            id: "@", 
	            data: "="  
	        },  
	        restrict: 'E',  
	        template: '<div style="height:180px; width:180px; margin-left: -20px"></div>',  
	        replace: true,  
	        link: function($scope, element, attrs, controller) {  
				var myChart = echarts.init(document.getElementById($scope.id),'macarons');  
	            var option = {
				    "animationDuration": [3000],
				    "tooltip": {
				        "trigger": 'item',
				        "formatter": "{a}"
				    },
				    "series": [{
				        "name": "交易成功率",
				        "center": [
				            "50%",
				            "50%"
				        ],
				        "radius": [
				            "50%",
				            "50%"
				        ],
				        "clockWise": false,
				        "hoverAnimation": false,
				        "type": "pie",
				        "data": [{
				            "value": $scope.data,
				            "name": "",
				            "label": {
				                "normal": {
				                    "show": true,
				                    "position": "center"
				                }
				            },
				            "labelLine": {
				                "show": false
				            },
				            "itemStyle": {
				                "normal": {
				                    "color": "#5886f0",
				                    "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
				                        offset: 0,
				                        color: 'rgba(59,193,244,1)'
				                    }, {
				                        offset: 1,
				                        color: 'rgba(59,193,244,0.5)'
				                    }]),
				                    "borderWidth": 5
				                }
				            },
				        }, {
				            "name": " ",
				            "value": 100-$scope.data,
				            "itemStyle": {
				                "normal": {
				                    "label": {
				                        "show": false
				                    },
				                    "labelLine": {
				                        "show": false
				                    },
				                    "color": '#f0efef',
				                    "borderColor": '#f0efef',
				                    "borderWidth": 5
				                }
				            }
				        }]
				    }]
				};
				console.log($scope.data);
            	myChart.setOption(option); 
			}
	    };  
	}); 
	module.directive('rate2', function() {  
	    return {  
	        scope: {  
	            id: "@", 
	            data: "="  
	        },  
	        restrict: 'E',  
	        template: '<div style="height:180px; width:180px; margin-left: -10px"></div>',  
	        replace: true,  
	        link: function($scope, element, attrs, controller) {  
				var myChart = echarts.init(document.getElementById($scope.id),'macarons');  
	            var option = {
				    "animationDuration": [3000],
				    "tooltip": {
				        "trigger": 'item',
				        "formatter": "{a} : ({d}%)"
				    },
				    "series": [{
				        "name": "交易变化率",
				        "center": [
				            "50%",
				            "50%"
				        ],
				        "radius": [
				            "50%",
				            "50%"
				        ],
				        "clockWise": false,
				        "hoverAnimation": false,
				        "type": "pie",
				        "data": [{
				            "value": $scope.data,
				            "name": "",
				            "label": {
				                "normal": {
				                    "show": true,
				                    "position": "center"
				                }
				            },
				            "labelLine": {
				                "show": false
				            },
				            "itemStyle": {
				                "normal": {
				                    "color": "#5886f0",
				                    "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
				                        offset: 0,
				                        color: 'rgba(194,139,221,1)'
				                    }, {
				                        offset: 1,
				                        color: 'rgba(194,139,221,0.5)'
				                    }]),
				                    "borderWidth": 5
				                }
				            },
				        }, {
				            "name": " ",
				            "value": 100-$scope.data,
				            "itemStyle": {
				                "normal": {
				                    "label": {
				                        "show": false
				                    },
				                    "labelLine": {
				                        "show": false
				                    },
				                    "color": '#f0efef',
				                    "borderColor": '#f0efef',
				                    "borderWidth": 5
				                }
				            }
				        }]
				    }]
				};
				console.log($scope.data);
            	myChart.setOption(option); 
			}
	    };  
	});
	module.directive('rate3', function() {  
	    return {  
	        scope: {  
	            id: "@", 
	            data: "="  
	        },  
	        restrict: 'E',  
	        template: '<div style="height:180px; width:180px; margin-left: -10px"></div>',  
	        replace: true,  
	        link: function($scope, element, attrs, controller) {  
				var myChart = echarts.init(document.getElementById($scope.id),'macarons');  
	            var option = {
				    "animationDuration": [3000],
				    "tooltip": {
				        "trigger": 'item',
				        "formatter": "{a} : ({d}%)"
				    },
				    "series": [{
				        "name": "交易响应率",
				        "center": [
				            "50%",
				            "50%"
				        ],
				        "radius": [
				            "50%",
				            "50%"
				        ],
				        "clockWise": false,
				        "hoverAnimation": false,
				        "type": "pie",
				        "data": [{
				            "value": $scope.data,
				            "name": "",
				            "label": {
				                "normal": {
				                    "show": true,
				                    "position": "center"
				                }
				            },
				            "labelLine": {
				                "show": false
				            },
				            "itemStyle": {
				                "normal": {
				                    "color": "#5886f0",
				                    "borderColor": new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
				                        offset: 0,
				                        color: 'rgba(245,113,195,1)'
				                    }, {
				                        offset: 1,
				                        color: 'rgba(245,113,195,0.5)'
				                    }]),
				                    "borderWidth": 5
				                }
				            },
				        }, {
				            "name": " ",
				            "value": 100-$scope.data,
				            "itemStyle": {
				                "normal": {
				                    "label": {
				                        "show": false
				                    },
				                    "labelLine": {
				                        "show": false
				                    },
				                    "color": '#f0efef',
				                    "borderColor": '#f0efef',
				                    "borderWidth": 5
				                }
				            }
				        }]
				    }]
				};
				console.log($scope.data);
            	myChart.setOption(option); 
			}
	    };  
	}); 
});