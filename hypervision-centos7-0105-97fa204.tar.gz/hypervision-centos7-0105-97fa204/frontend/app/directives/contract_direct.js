define([
    'angular',
], function () {
    var module = angular.module('directives');

    module.directive('mySelect', function ($document) {
        return {
            restrict: 'E',
            scope: {
                list: '=list',
                style: '=style',
                returns: '=returns',
                default: '=default',
                defaultTitle: '=defaulttitle'
            },
            replace: true,
            link: function (scope, element) {
                scope.listVisible = false;
                scope.titleTitle = scope.defaultTitle;
                scope.selected = scope.default;
                if (scope.default == '') {
                    scope.selected = [];
                }
                scope.open = function () {
                    scope.listVisible = !scope.listVisible;
                }
                scope.select = function (i) {
                    scope.selected = i;
                    scope.returns(i);
                    scope.open();
                }
                $document.bind('click', function (event) {
                    if (element[0].contains(event.target))
                        return;
                    scope.listVisible = false;
                    scope.$apply();
                });
            },
            templateUrl: 'app/templates/directives/myselect.html'
        };
    });

    module.directive('endpointSelect', function ($document) {
        return {
            restrict: 'E',
            scope: {
                list: '=list',
                style: '=style',
                returns: '=returns',
                default: '=default'
            },
            replace: true,
            link: function (scope, element) {
                scope.listVisible = false;
                scope.listVisible = false;
                scope.selected = scope.default;
                scope.open = function () {
                    scope.listVisible = !scope.listVisible;
                };
                scope.select = function (chainId, chainName, containerId) {
                    endpoint = {
                        chainId: chainId,
                        chainName: chainName,
                        containerId: containerId
                    };
                    scope.selected = endpoint;
                    scope.returns(endpoint);
                    scope.open();
                };
                $document.bind('click', function (event) {
                    if (element[0].contains(event.target))
                        return;
                    scope.listVisible = false;
                    scope.$apply();
                });
            },
            templateUrl: 'app/templates/directives/endpointselect.html'
        };
    });

    module.directive('myModal', function () {
        return {
            restrict: 'E',
            scope: {
                show: '=',
                title: '@'
            },
            replace: true,
            transclude: true,
            link: function (scope, element, attrs) {
                scope.dialogStyle = {};
                if (attrs.width)
                    scope.dialogStyle.width = attrs.width;
                if (attrs.height)
                    scope.dialogStyle.height = attrs.height;
                //var body = element[0].querySelector('.contract-modal-body');
                //$(body).css('height', (parseInt(attrs.height) - 65) + 'px');
                scope.hideModal = function () {
                    scope.show = false;
                };
            },
            templateUrl: 'app/templates/directives/mymodal.html'
        };
    });

    module.directive('tab', function(){
        return {
            restrict: 'A',
            replace: true,
            link: function (scope, element, addr) {
                element.find('span').bind('click', function(){
                    var _this = $(this);
                    if (!(_this.hasClass("selected"))) {
                        _this.addClass("selected").siblings().removeClass("selected");
                    }
                    var text = _this.html();
                    if (text == "source") {
                        $("#detail-form").children("div").hide()
                        $("#contract_detail_content").show();
                    } else if (text == "abi") {
                        $("#detail-form").children("div").hide()
                        $("#abi").show();
                    }else if (text == "code") {
                        $("#detail-form").children("div").hide()
                        $("#code").show();
                    }
                })
            }
        };
    })
});